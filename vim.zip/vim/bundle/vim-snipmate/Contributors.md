# Contributors #

SnipMate was originally authored by Michael Sanders
([Vim](http://www.vim.org/account/profile.php?user_id=16544),
[GitHub](https://github.com/msanders)).

It is currently maintained by [Rok Garbas](rok@garbas.si), [Marc
Weber](marco-oweber@gmx.de), and [Adnan Zafar](https://github.com/ajzafar) with
additional contributions from:

* [907th](https://github.com/907th)
* [adkron](https://github.com/adkron)
* [alderz](https://github.com/alderz)
* [asymmetric](https://github.com/asymmetric)
* [bpugh](https://github.com/bpugh)
* [bruno-](https://github.com/bruno-)
* [CharlesGueunet](https://github.com/CharlesGueunet)
* [darkwise](https://github.com/darkwise)
* [dreviejo](https://github.com/dreviejo)
* [fish-face](https://github.com/fish-face)
* [henrik](https://github.com/henrik)
* [holizz](https://github.com/holizz)
* [honza](https://github.com/honza)
* [hpesoj](https://github.com/hpesoj)
* [ironcamel](https://github.com/ironcamel)
* [jb55](https://github.com/jb55)
* [jbernard](https://github.com/jbernard)
* [jherdman](https://github.com/jherdman)
* [kozo2](https://github.com/kozo2)
* [lilydjwg](https://github.com/lilydjwg)
* [lpil](https://github.com/lpil)
* [marutanm](https://github.com/marutanm)
* [MicahElliott](https://github.com/MicahElliott)
* [mikeastock](https://github.com/mikeastock)
* [muffinresearch](https://github.com/muffinresearch)
* [munyari](https://github.com/munyari)
* [pielgrzym](https://github.com/pielgrzym)
* [pose](https://github.com/pose)
* [r00k](https://github.com/r00k)
* [radicalbit](https://github.com/radicalbit)
* [redpill](https://github.com/redpill)
* [rglassett](http://github.com/rglassett)
* [robhudson](https://github.com/robhudson)
* [shinymayhem](https://github.com/shinymayhem)
* [Shraymonks](https://github.com/shraymonks)
* [sickill](https://github.com/sickill)
* [statik](https://github.com/statik)
* [steveno](https://github.com/steveno)
* [taq](https://github.com/taq)
* [thisgeek](https://github.com/thisgeek)
* [trusktr](https://github.com/trusktr)
* [Xandaros](https://github.com/Xandaros)
