# include "stdio.h"
# include "ncurses.h"
# include "ctype.h"
const int pre=800;
int main (void) 
{
  char s,o,pr;
  int e,bu=0,tar,td=0;
  o=' ';
  system("clear");
  while(o!='F'){
                 printf("\n\n\t**************************************************");
                 printf("\n\n\t\t\tPROGRAMA TICKETS");
                 printf("\n\n\t**************************************************");
                 printf("\n\n\t\tRESUMEN(R)   TICKETS(T)   FIN(F):    ",getchar());
                 o=toupper(getchar());
                 system("clear");
                 if(o=='T'){
                             pr=' ';
                             while(pr!='N'){
                                             printf("\n\n\t*************************************************");
                                             printf("\n\n\t\t\tPROGRAMA TICKETS");
                                             printf("\n\n\t*************************************************");
                                             printf("\n\n\tDIGITE EDAD:    ");
                                             scanf("%d",&e);
                                             bu=bu+1;
                                             if(e<6){
                                                         printf("\n\n\t\t\t|  NIÑO  |");
                                                         tar=0;
                                                        }
                                             if((e>=6)&&(e<18)){
                                                                  printf("\n\n\t\t\t|   JOVEN   |");
                                                                  tar=pre/2;
                                                                 }
                                             if((e>=18)&&(e<50)){
                                                                  printf("\n\n\t\t\t|    ADULTO    |");
                                                                  tar=pre;
                                                                 }
                                             if(e>=50){
                                                          printf("\n\n\t\t\t|     JUBILADO    |");
                                                          tar=pre/4;
                                                         }
                                             td=td+tar;
                                             printf("\n\n\t\t|  TOTAL =  %d  |  ",tar);
                                             printf("\n\n\t\tQUIERE OTRO TICKETS:    ",getchar());
                                             pr=toupper(getchar());
                                             system("clear");
                                            }
                             }
                 if(o=='R'){
                             printf("\n\n\t*****************************************************");
                             printf("\n\n\t\t\tRESUMEN TICKETS");
                             printf("\n\n\t*****************************************************");
                             printf("\n\n\t\tTOTAL TICKETS   =   %d",bu);
                             printf("\n\n\t\tTOTAL DINERO    =   %d",td);
                             printf("\n\n\t*****************************************************");
                           }
               }
    printf("\n\nPRESIONE TECLA EN LA TERMINACION DEL SOFTWARE:    ",getchar());
    s=getchar();
    system("clear");
    return 0;        
                           
                                       
}
