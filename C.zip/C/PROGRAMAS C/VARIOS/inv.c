/**
 * 	Inventario
 *
 * 	Programa que manipula datos (codigo, nombre, precio y existencias)
 * 	de productos (de una tienda de abarrotes, por ejemplo), cuenta con
 * 	las siguientes especificaciones:
 *
 * 	- Contraseña para ingresar al sistema
 * 	- Interfaz por consola
 * 	- Exportacion de datos a ficheros de texto
 * 	- Guardado de la informacion para posterior lectura
 * 	- Lectura de archivos de inventario (generados con este programa)
 * 	- Busqueda, Consulta, Actualizacion y Eliminacion de los datos al-
 * 	  macenados
 *
 * 	*NOTA* Solo funciona correctamente en linux :v
 *
 * 	Para compilar:
 *
 * 		gcc -o inventario inv.c -std=c99
 *
 * 	Para ejecutar, contraseña por defecto (123asd):
 *
 * 		./inventario
 * 
 * 	@version 1.0
 *	@author Eduardo B. <ms7rbera@gmail.com>
 * 	@license MIT
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

//Tamanio que tendra el inventario
#define TAMANIO_DE_INVENTARIO 15
//Al introducir mal la contrasenia un numero mañor

//de veces al indicado aqui, el programa saldra
#define NUMERO_DE_INTENTOS_DE_LOGIN 3

//contraseña del programa
#define PASS "123asd"

//Contador de productos agregados
int PRODUCT_COUNT = 0;

//representa un espacio disponible en
//la estructura, de algun producto eliminado
int DIAPOSABLE_SPACE = -1;

//Estructura de producto
typedef struct
{
  int CODE;
  char NAME[15];
  int EXIST;
  float PRICE;
}PRODUCT;

//Union del inventario
union INVENTARIO
{
  PRODUCT producto[TAMANIO_DE_INVENTARIO];
}Inventario;

/**
 *  reposiciona el puntero a (x,y) (lineas, caracteres)
 */
void gotoXY(int x, int y)
{
  printf("%c[%d;%df",0x1B,x,y);
}//gotoXY ends

/**
 * pausa la ejecucion del programa
 */
void pause() {
  char pause;
  printf("\n pulse una tecla para continuar...");
  //NO se por que funciona solo poniendolo 2 veces xD
  pause = getchar();
  pause = getchar();
}//pause ends

/**
 * Muestra el menu
 */
void mostrarMenu()
{
  printf("\n +----------------------------------------------------------------------------+");
  printf("\n |                                                                            |");
  printf("\n |                                 INVENTARIO v1.0                            |");
  printf("\n |                                                                            |");
  printf("\n +----------------------------------------------------------------------------+");
  printf("\n |   MENU DE OPCIONES:                                                        |");
  printf("\n |                         1) Mostrar inventario                              |");
  printf("\n |                         2) Agregar producto                                |");
  printf("\n |                         3) Borrar producto                                 |");
  printf("\n |                         4) Buscar producto                                 |");
  printf("\n |                         5) Actualizar producto                             |");
  printf("\n |                         6) Exportar archivo                                |");
  printf("\n |                         7) Guardar                                         |");
  printf("\n |                         8) Abrir                                           |");
  printf("\n |                         9) Salir                                           |");
  printf("\n +----------------------------------------------------------------------------+");
}//mostarMenu ends

/**
 * Muestra una caja de mensaje
 */
void MBox(char* msg, char symbol)
{
  //Limpia la pantalla
  system("clear");
  printf(" +----------------------------------------------------------------------------+\n");
  printf(" |  [ ]                                                                       |\n");
  printf(" +----------------------------------------------------------------------------+\n");
  //repocicion del puntero al renglon 2 caracter 6
  gotoXY(2,6);
  printf("%c", symbol);
  //repocicion del puntero al renglon 2 caracter 10
  gotoXY(2,10);
  printf("%s\n\n", msg);
}//MBox ends

/**
 * carga un archivo
 */
void abrir()
{
  //variable para nombre de archivo
  char FILE_NAME[15];
  //variable para ir almacenando las lineas del archivo
  char linea[15];
  //variable para contar las lineas avanzadas
  int LINE_COUNT = 0;
  //variable para contar los elementos leidos
  int ELEMENTS_COUNT = 0;
  // variable 'fp' tipo FILE
  FILE *fp;

  printf(" +----------------------------------------------------------------------------+\n");
  printf(" | Abrir : _______________ (max. 15 chars)                             [ALL]  |\n");
  printf(" +----------------------------------------------------------------------------+\n\n");
  printf(" Ficheros disponibles: \n\n");
  //Imprime los archivos disponibles en el directorio actual
  //con extencion '.inv'
  system("ls *.inv");
  //reposicion del cursor
  gotoXY(2,12);
  scanf("%s", FILE_NAME);
  //Abrir el fichero en modo lectura
  fp = fopen(FILE_NAME, "r");
  //Verifica que se alla podido abrir
  if(fp == NULL)
  {
    //En caso de que sea NULL quiere decir que no se pudo abrir
    MBox("El fichero no se pudo encontrar",'!');
  }
    else
  {
    //Recorremos linea por linea el fichero
    //(el contenido de la linea se almacena en 'linea')
    while(fgets(linea,15,fp) != NULL)
    {
      //Miramos en que linea estamos
      switch(LINE_COUNT)
      {
	// linea 0 representa el codigo del producto
	case 0:
	  //atoi - convierte el valor de linea a entero
	  Inventario.producto[ELEMENTS_COUNT].CODE = atoi(linea);
	  break;
	// linea 1 representa el nombre
	case 1:
	  //Copia el contenido de linea a NAME
	  strcpy(Inventario.producto[ELEMENTS_COUNT].NAME, linea);
	  break;
	//linea 2 representa el numero de existencias
	case 2:
	  Inventario.producto[ELEMENTS_COUNT].EXIST = atoi(linea);
	  break;
	//linea 3 representa el precio
	case 3:
	  //atof - convierte el valor de linea a flotante
	  Inventario.producto[ELEMENTS_COUNT].PRICE = atof(linea);
	  //Resetea el contador de linea
	  LINE_COUNT = -1;
	  //Aumenta los contadores de elementos
	  ELEMENTS_COUNT++;
	  PRODUCT_COUNT++;
	  break;
      }
      //aumenta contador de linea
      LINE_COUNT++;
    }
    //Indicamos que se cargo correctamente
    MBox("El archivo se cargo correctamente",'i');
  }
}//abrir ends

/**
 * Guarda la informacion en un fichero de texto
 * entendible solo para el programa
 */
void guardar()
{
  //para guardar el nombre del archivo
  char FILE_NAME[15];
  FILE *fp;

  //verifica que alla productos en el inventario
  if(PRODUCT_COUNT)
  {
    printf(" +----------------------------------------------------------------------------+\n");
    printf(" | Guardar como: _______________ (max. 15 chars)                      [ALL]  |\n");
    printf(" +----------------------------------------------------------------------------+\n");
    //reposicion del cursor
    gotoXY(2,18);
    scanf("%s", FILE_NAME);
    //Concatena 'FILE_NAME' con '.inv'
    strcat(FILE_NAME,".inv");
    //Abrimos el archivo en modo escritura
    fp = fopen(FILE_NAME, "w");
    //Recorremos cada uno de los productos en el inventario
    for(int i = 0;i < PRODUCT_COUNT;i++)
    {
      //Verifica que no contenga el caracter de 'eliminado'
      if(Inventario.producto[i].NAME[0] != '#')
      {
	//'fprintf' imprime dentro del archivo, no en pantalla
	fprintf(fp,"%d\n",Inventario.producto[i].CODE);
  	fprintf(fp,"%s\n",Inventario.producto[i].NAME);
  	fprintf(fp,"%d\n",Inventario.producto[i].EXIST);
  	fprintf(fp,"%f\n",Inventario.producto[i].PRICE);
      }
    }
    //Cierra el archivo
    fclose(fp);
    //limpia la pantalla
    system("clear");
    printf(" +----------------------------------------------------------------------------+\n");
    printf(" |  [i]                                                                       |\n");
    printf(" +----------------------------------------------------------------------------+\n");
    gotoXY(2,10);
    printf("Fichero guardado en: %s\n\n", FILE_NAME);

  }
    else
  {
    MBox("El inventario esta vacio!",'!');
  }
}//guardar ends

/**
 * Exporta el inventario a una archivo de texto
 * entendible para el usuario
 */
void exportar()
{
  char FILE_NAME[15];
  FILE *fp;

  if(PRODUCT_COUNT)
  {
    printf(" +----------------------------------------------------------------------------+\n");
    printf(" | Exportar como: _______________ (max. 15 chars)                      [ALL]  |\n");
    printf(" +----------------------------------------------------------------------------+\n");
    gotoXY(2,19);
    scanf("%s", FILE_NAME);
    //Concatena 'FILE_NAME' con '.txt'
    strcat(FILE_NAME,".txt");
    //Abrir archivo en modo escritura
    fp = fopen(FILE_NAME, "w");
    //Imprime dentro del archivo la cabecera
    fprintf(fp,"%s"," +-------------------------------------------------------------------+\n");
    fprintf(fp,"%s"," |                         INVERTARIO                                |\n");
    fprintf(fp,"%s"," +-------------------------------------------------------------------+\n\n");
    //hay que recorrer cada producto en el inventario
    for(int i = 0;i < PRODUCT_COUNT;i++)
    {
      if(Inventario.producto[i].NAME[0] != '#')
      {
	//ver el formato de salida en una exportacion
	//para entender mejor esta parte
  	fprintf(fp,"\n(%s)\n",Inventario.producto[i].NAME);
  	fprintf(fp,"{\n\tid : [%d],",Inventario.producto[i].CODE);
  	fprintf(fp,"\n\texistencias : [%d],",Inventario.producto[i].EXIST);
  	fprintf(fp,"\n\tprecio : [%f]",Inventario.producto[i].PRICE);
  	fprintf(fp,"%s","\n}\n");
      }
    }
    //Imprime en el archivo el pie de la exportacion
    fprintf(fp,"\n\n Total de productos: %d\n\n", PRODUCT_COUNT);
    fprintf(fp,"%s"," +-------------------------------------------------------------------+\n");
    fprintf(fp,"%s"," |                 INVERTARIO v1.0 by Eduardo B.                     |\n");
    fprintf(fp,"%s"," +-------------------------------------------------------------------+\n");
    //cierra el archivo
    fclose(fp);
    //Limpia pantalla
    system("clear");
    printf(" +----------------------------------------------------------------------------+\n");
    printf(" |  [i]                                                                       |\n");
    printf(" +----------------------------------------------------------------------------+\n");
    gotoXY(2,10);
    printf("Fichero exportado en: %s\n\n", FILE_NAME);
    
  }
    else
  {
    MBox("El inventario esta vacio!",'!');
  }
}//exportar ends

/**
 * Muestra el inventario en pantalla
 */
void mostrarInventario()
{
  //Contador de linea en por que la cabecera ocupa los primeros 3
  int LINE_COUNT = 4;
  //limpia pantalla
  system("clear");
  //verifica que alla productos en el inventario
  if(PRODUCT_COUNT)
  {
    //Imprime cabecera
    printf(" +----------------------------------------------------------------------------+\n");
    printf(" |       CODIGO        |         NOMBRE         |   PRECIO   |   EXISTENCIAS  |\n");
    printf(" +----------------------------------------------------------------------------+\n");
  }
    else
  {
    //inventario vacio
    MBox("Inventario vacio",'i');
  }

  //Recorremos cada producto del inventario
  for(int i = 0;i < PRODUCT_COUNT;i++)
  {
    //Verifica que el primer caracter del nombre no sea '#'
    //(si lo tiene significa que el producto de ese espacio
    //fue eliminado)
    if(Inventario.producto[i].NAME[0] != '#')
    {
      //repocicion del cursor
      gotoXY(LINE_COUNT,0);
      printf(" |                     |                        |            |                |\n");
      printf(" +----------------------------------------------------------------------------+\n");
      gotoXY(LINE_COUNT,4);
      printf("%d",Inventario.producto[i].CODE);
      gotoXY(LINE_COUNT, 26);
      printf("%s",Inventario.producto[i].NAME);
      gotoXY(LINE_COUNT, 51);
      printf("%f",Inventario.producto[i].PRICE);
      gotoXY(LINE_COUNT, 64);
      printf("%d\n\n",Inventario.producto[i].EXIST);
      //aumenta en 2 ya que cada impresion de cada producto ocupa 2 lineas
      LINE_COUNT += 2;
    }
  }
  //Imprime pie si hay productos en el inventario
  if(PRODUCT_COUNT)
  {
    printf(" [                                INVENTARIO                                  ]\n");
    printf(" +----------------------------------------------------------------------------+\n");
  }
}//mostrarInventario ends

/**
 * Agrega un producto
 */
void agregar()
{
  //Variable que indica el indice donde sera agregado el producto
  int INDEX;
  // != -1 ya que tambien puede ser 0
  if(DIAPOSABLE_SPACE != -1)
  {
    //Si hay un espacio disponible
    //El indice sera el indicado por el espacio disponible
    INDEX = DIAPOSABLE_SPACE;
  }
    else
  {
    //Si no hay espacio disponible
    //el indice sera el contador de productos
    //(la ultima posicion del inventario)
    INDEX = PRODUCT_COUNT;
  }

  printf(" +----------------------------------------------------------------------------+\n");
  printf(" |[ID del producto]     :  ________________                            [INT]  |\n");
  printf(" +----------------------------------------------------------------------------+\n");
  printf(" |[Nombre del producto] :  ________________ (max.15 chars)             [ALL]  |\n");
  printf(" +----------------------------------------------------------------------------+\n");
  printf(" |[Existencias]         :  ________________                            [INT]  |\n");
  printf(" +----------------------------------------------------------------------------+\n");
  printf(" |[Precio]              :  ________________                            [DEC]  |\n");
  printf(" +----------------------------------------------------------------------------+\n");
  printf(" |                               AGREGAR PRODUCTO                             |\n");
  printf(" +----------------------------------------------------------------------------+\n");
  
  gotoXY(2,28);
  scanf("%d", &Inventario.producto[INDEX].CODE);
  gotoXY(4,28);
  scanf("%s", Inventario.producto[INDEX].NAME);
  gotoXY(6,28);
  scanf("%d", &Inventario.producto[INDEX].EXIST);
  gotoXY(8,28);
  scanf("%f", &Inventario.producto[INDEX].PRICE);
  MBox("INFORMACION GUARDADA CON EXITO! :D",'i');

  if(DIAPOSABLE_SPACE == -1)
  {
    //Si hubo hay espacio disponible aumenta el contador de productos
    PRODUCT_COUNT++;
  }
    else
  {
    //de lo contrario resetea el espacio disponible
    DIAPOSABLE_SPACE = -1;
  }
}//agregar ends

/**
 * Actulizar producto
 */
void actualizar()
{
  int CODE;
  //vandera para indicar si la busqueda y actualizacion
  //tuvo exito
  short FLAG = 0;
  //limpia pantalla
  system("clear");
  printf(" +----------------------------------------------------------------------------+\n");
  printf(" | ID de producto : _______________                                    [INT]  |\n");
  printf(" +----------------------------------------------------------------------------+\n");
  printf(" |                                 ACTUALIZAR                                 |\n");
  printf(" +----------------------------------------------------------------------------+\n");
  gotoXY(2,21);
  scanf("%d", &CODE);

  for(int i = 0; i < PRODUCT_COUNT;i++)
  {
    //Si el ID indicado coincide con el de
    //el producto i del inventario
    //pide los nuevos datos y los guarda en esa posicion (i)
    if(Inventario.producto[i].CODE == CODE)
    {
      //Limpia pantalla
      system("clear");
      printf(" +----------------------------------------------------------------------------+\n");
      printf(" |[ID del producto]     :  ________________                            [INT]  |\n");
      printf(" +----------------------------------------------------------------------------+\n");
      printf(" |[Nombre del producto] :  ________________ (max.15 chars)             [ALL]  |\n");
      printf(" +----------------------------------------------------------------------------+\n");
      printf(" |[Existencias]         :  ________________                            [INT]  |\n");
      printf(" +----------------------------------------------------------------------------+\n");
      printf(" |[Precio]              :  ________________                            [DEC]  |\n");
      printf(" +----------------------------------------------------------------------------+\n");
      printf(" |                             ACTUALIZAR PRODUCTO                            |\n");
      printf(" +----------------------------------------------------------------------------+\n");

      gotoXY(2,28);
      scanf("%d", &Inventario.producto[i].CODE);
      gotoXY(4,28);
      scanf("%s", Inventario.producto[i].NAME);
      gotoXY(6,28);
      scanf("%d", &Inventario.producto[i].EXIST);
      gotoXY(8,28);
      scanf("%f", &Inventario.producto[i].PRICE);
      //Cambiamos el estado de la bandera ya que el producto
      //fue actualizado
      FLAG = 1;
      //Para salir del for
      i = PRODUCT_COUNT + 1;
    }
  }

  if(FLAG)
  {
    //hay bandera, el producto fue actualizado
    MBox("Producto actualizado correctamente :D",'i');
  } else {
    //no hay bandera
    MBox("El producto no esta registrado! D:",'!');
  }
}//actualizar ends

/**
 * Elimina un elemento
 */
void eliminar()
{
  int CODE;
  //Bandera que indica si la busqueda y eliminacion
  //tuvieron exito
  short FLAG = 0;

  printf(" +----------------------------------------------------------------------------+\n");
  printf(" | ID de producto : _______________                                    [INT]  |\n");
  printf(" +----------------------------------------------------------------------------+\n");
  printf(" |                                  ELIMINAR                                  |\n");
  printf(" +----------------------------------------------------------------------------+\n");
  gotoXY(2,21);
  scanf("%d", &CODE);
  
  for(int i = 0; i < PRODUCT_COUNT;i++)
  {
    //Mismo procedimiento que en la actualizacion
    //pero en vez de pedir y actualizar los datos
    //del producto en la posicion (i), lo que
    //hace es cambiar el primer caracter del nombre
    //por un '#' para que este producto sea ignorado
    //a la hora de (mostrar, exportar, guardar)
    if(Inventario.producto[i].CODE == CODE)
    {
      Inventario.producto[i].NAME[0] = '#';
      FLAG = 1;
      DIAPOSABLE_SPACE = i;
      i = PRODUCT_COUNT + 1;
    }
  }

  if(FLAG)
  {
    MBox("Producto eliminado >:D",'i');
  } else {
    MBox("El producto no esta registrado! D:",'!');
  }
}//eliminar ends

/**
 * Busca un producto
 */
void buscar()
{
  int CODE;
  short FLAG = 0;

  printf(" +----------------------------------------------------------------------------+\n");
  printf(" | ID de producto : _______________                                    [INT]  |\n");
  printf(" +----------------------------------------------------------------------------+\n");
  printf(" |                                   BUSCAR                                   |\n");
  printf(" +----------------------------------------------------------------------------+\n");
  gotoXY(2,21);
  scanf("%d", &CODE);
  system("clear");
  
  for(int i = 0; i < PRODUCT_COUNT;i++)
  {
    //Mismo procedimiento que en eliminary actualizar
    //Solo que al encontrar el producto solo
    //imprime los datos de este
    if(Inventario.producto[i].CODE == CODE)
    {
      printf(" +----------------------------------------------------------------------------+\n");
      printf(" |       CODIGO        |         NOMBRE         |   PRECIO   |   EXISTENCIAS  |\n");
      printf(" +----------------------------------------------------------------------------+\n");
      printf(" |                     |                        |            |                |\n");
      printf(" +----------------------------------------------------------------------------+\n");
      printf(" |                           RESULTADO DE LA BUSQUEDA                         |\n");
      printf(" +----------------------------------------------------------------------------+\n\n");
      gotoXY(4,4);
      printf("%d",Inventario.producto[i].CODE);
      gotoXY(4, 26);
      printf("%s",Inventario.producto[i].NAME);
      gotoXY(4, 51);
      printf("%f",Inventario.producto[i].PRICE);
      gotoXY(4, 64);
      printf("%d\n\n\n",Inventario.producto[i].EXIST);
      FLAG = 1;
      i = PRODUCT_COUNT + 1;
    }
  }

  if(!FLAG)
  {
    MBox("Al parecer el producto no existe :C",'!');
  }
}//buscar ends

/**
 * Pide al usuario insertar la contraseña cierto numero de veces
 * si es incorrecta no entra al programa
 */
int pedirContrasenia()
{
  //para indicar si fue correcta o no
  int CORRECTA = 0;
  char _pass[15];
  //Imprime mensaje de bienvenida
  MBox("Welcome!",'*');
  //For que va desde 1 hasta los intentos de login
  //permitidos
  for(int i = 1; i <= NUMERO_DE_INTENTOS_DE_LOGIN; i++)
  {
    printf("\n\n System password: ");
    scanf("%s", _pass);
    //verifica que la contrasenia introducida coincida
    //con la del sistema
    if(!strcmp(_pass, PASS))
    {
      //Cambia el estado de la bandera para
      //indicar que el logeo tuvo exito
      CORRECTA = 1;
      //para salir del for
      i = NUMERO_DE_INTENTOS_DE_LOGIN + 1;
    }
      else
    {
      //Muestra mensaje de contrasenia incorrecta
      MBox("Invalid password, retry again ...",'!');
    }
  }

  //La bandera indica que el login tuvo exito
  if(CORRECTA)
  {
    //regresa 0 (ver main)
    return 0;
  }
    else
  {
    //Liampia pantalla
    system("clear");
    //Muestra mensaje de error
    printf("\n [!] Bad password was typed %d times! \n [*] Exiting...\n", NUMERO_DE_INTENTOS_DE_LOGIN);
    //regresa 1 (ver main)
    return 1;
  }

}//pedirContrasenia ends

/**
 * MAIN
 */
int main()
{
  //para guardar la opcion que elija el usuario
  short opcion;
  //Bandera que indica al programa si debe salir
  short SALIR;
  //SALIR tomara el valor devuelto por pedirContrasenia()
  // 0 => es correcta
  // 1 => es incorrecta
  SALIR = pedirContrasenia();
  //Mientras SALIR negado sea verdadero, es decir
  //lo hara mientras SALIR sea 0 (por eso pedirContrasenia retorna 0
  //si la contrasenia fue correcta)
  while(!SALIR)
  {
    //Limpia pantalla
    system("clear");
    //muestra menu
    mostrarMenu();
    //Promt
    printf("\n\n  [OPCION] >> ");
    scanf("%i", &opcion);
    //Evalua la opcion elejida por el usuario
    switch(opcion)
    {
      //Mostrar inventario
      case 1:
	system("clear");
	mostrarInventario();
	pause();
	break;
      //Agregar producto
      case 2:
	system("clear");
	agregar();
	pause();
	break;
      //Eliminar producto
      case 3:
	system("clear");
	eliminar();
	pause();
	break;
      //Buscar producto
      case 4:
	system("clear");
	buscar();
	pause();
	break;
      case 5:
      //Actualizar producto
	system("clear");
	actualizar();
	pause();
	break;
      case 6:
      //Exportar
	system("clear");
	exportar();
	pause();
	break;
      //Guardar
      case 7:
	system("clear");
	guardar();
	pause();
	break;
      //Abrir
      case 8:
	system("clear");
	abrir();
	pause();
	break;
      //Salir
      case 9:
	system("clear");
	SALIR = 1;
	break;
      //Ninguna de las anteriores
      default:
	system("clear");
	printf("\n [!ERROR]: La opcion %i no es valida! \n", opcion);
	pause();
	mostrarMenu();
	break;	
    }
  }
}//main ends