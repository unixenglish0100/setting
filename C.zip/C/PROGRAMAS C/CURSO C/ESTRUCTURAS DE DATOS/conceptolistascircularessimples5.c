#include<stdio.h>
#include<stdlib.h>

typedef struct nodo{
int dato;
struct nodo* siguiente;
}nodo;

nodo* primero=NULL;
nodo* ultimo=NULL;

void introducirnodo();
void buscarnodo();
void modificarnodo();
void desplegarlistacircularsimple();
void eliminarnodo();

int main(){
system("clear");
int op;
char key='s';

do{
   do{
       printf("\n|----------------------------------|");
       printf("\n|          CONCEPTO DE PILA        |");
       printf("\n|----------------------------------|");
       printf("\n|1. introducir    |   4. eliminar  |");
       printf("\n|2. buscar        |   5. desplegar |");
       printf("\n|3. modificar     |   6. salir     |");
       printf("\n|__________________________________|");
       printf("\nescoja una opcion:   ");
       scanf("%i",&op);
     }while(op<1 || op>6);

   switch(op){
	       case 1: introducirnodo(); break;
	       case 2: buscarnodo(); break;
	       case 3: modificarnodo(); break;
	       case 4: eliminarnodo(); break;
	       case 5: desplegarlistacircularsimple(); break;
	       case 6: printf("\nprograma finalizado\n"); break;
	       default: printf("\nopcion no valida\n");	       
             }
   printf("\nretornar programa(s/n):   ",getchar());
   key=getchar();
   system("clear");
  }while(key=='s' || key=='S');
return 0;
}

void introducirnodo(){
	             nodo* nuevo=(nodo*) malloc(sizeof(nodo));
		     printf("\ningrese el dato en el nuevo nodo:  ");
		     scanf("%i",&nuevo->dato);
		     if(primero==NULL){
			                primero=nuevo;
					primero->siguiente=primero;
					ultimo=nuevo;
		                      }
		     else{
			   ultimo->siguiente=nuevo;
			   nuevo->siguiente=primero;
			   ultimo=nuevo;
		         }
		     printf("\ndato nodo cola introducido exitosamente\n");
                   }


void buscarnodo(){
	              int bn=0;
		      int enc=0;
	              nodo* actual=(nodo*) malloc(sizeof(nodo));
		      actual=primero;
		      printf("\ningrese el dato del nodo a buscar:   ");
		      scanf("%i",&bn);
		      if(primero!=NULL){
					 do{
				            if(actual->dato==bn){
						                  printf("\nel dato nodo lista circular simple (%i) encontrado con exito\n",bn);
								  enc=1;
					                        } 
					    actual=actual->siguiente;
					   }while(actual!=primero && enc==0);
			                 printf("\n\n");
					 if(enc==0){
						     printf("\nnodo no encontrado\n\n");
					           }
		                       }
		      else{
			    printf("\nla lista simple se encuentra vacia\n");
		          }
                 }

void modificarnodo(){
	              int nb=0;
		      int enc=0;
	              nodo* actual=(nodo*) malloc(sizeof(nodo));
		      actual=primero;
		      printf("\ningrese el dato del nodo a buscar para modificar:   ");
		      scanf("%i",&nb);
		      if(primero!=NULL){
					 do{
					    if(actual->dato==nb){
						                  printf("\n\ndato nodo lista circular simple (%i) encontrado con exito",nb);
								  printf("\ndigite nuevo dato nodo:   ");
								  scanf("%i",&actual->dato);
								  printf("\ndato nodo lista circular simple modificado con exito\n");
								  enc=1;
					                        }	
					   actual=actual->siguiente; 
					   }while(actual!=primero && enc==0);
			                 printf("\n\n");
					 if(enc==0){
						     printf("\nnodo no encontrado\n\n");
					           }
		                       }
		      else{
			    printf("\nla lista simple se encuentra vacia\n");
		          }
                    }


void eliminarnodo(){
	              int nb=0;
		      int enc=0;
	              nodo* actual=(nodo*) malloc(sizeof(nodo));
		      nodo* anterior=(nodo*) malloc(sizeof(nodo));
		      anterior=NULL;
		      printf("\ningrese el dato del nodo a buscar para eliminar:   ");
		      scanf("%i",&nb);
		      actual=primero;
		      if(primero!=NULL){
					 do{
					    if(actual->dato==nb){
						                  if(actual==primero){
								                       primero=primero->siguiente;
								  		       ultimo->siguiente=primero;
							                             }
							          else if(actual==ultimo){
								                           anterior->siguiente=primero;
									   	           ultimo=anterior;
							                                 }
							          else{
								         anterior->siguiente=actual->siguiente;
							              }
								  printf("\ndato nodo eliminado con exito en lista circular simple\n");
								  enc=1
									  enc=1;
					                        }
				            anterior=actual;
				            actual=actual->siguiente;	    
					   }while(actual!=primero && enc==0);
			                 printf("\n\n");
					 if(enc==0){
						     printf("\nnodo no encontrado\n\n");
					           }
					 else{
					       free(anterior);
					     }
		                       }
		      else{
			    printf("\nla lista simple se encuentra vacia\n");
		          }
                   }


void desplegarlistacircularsimple(){
	                             nodo* actual=(nodo*) malloc(sizeof(nodo));
		                     actual=primero;
		                     if(primero!=NULL){
				  	                do{
					                    printf("\n%i",actual->dato); 	 
				                            actual=actual->siguiente;		 
			                                  }while(actual!=primero);			 
					                printf("\n\n");
		                                      }
		                     else{
			                   printf("\nla lista simple se encuentra vacia\n");
		                         }
                                   }
