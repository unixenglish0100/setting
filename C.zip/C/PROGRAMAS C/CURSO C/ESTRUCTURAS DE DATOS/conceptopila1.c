#include<stdio.h>
#include<stdlib.h>

typedef struct nodo{
int dato;
struct nodo* siguiente;
}nodo;

nodo* primero=NULL;

void introducirnodo();
void buscarnodo();
void modificarnodo();
void desplegarnodo();
void eliminarnodo();

int main(){
system("clear");
int op;
char key='s';

do{
   do{
       printf("\n|----------------------------------|");
       printf("\n|          CONCEPTO DE PILA        |");
       printf("\n|----------------------------------|");
       printf("\n|1. introducir    |   4. eliminar  |");
       printf("\n|2. buscar        |   5. desplegar |");
       printf("\n|3. modificar     |   6. salir     |");
       printf("\n|__________________________________|");
       printf("\nescoja una opcion:   ");
       scanf("%i",&op);
     }while(op<1 || op>6);

   switch(op){
	       case 1: introducirnodo(); break;
	       case 2: buscarnodo(); break;
	       case 3: modificarnodo(); break;
	       case 4: eliminarnodo(); break;
	       case 5: desplegarnodo(); break;
	       case 6: printf("\nprograma finalizado\n"); break;
	       default: printf("\nopcion no valida\n");	       
             }
   printf("\nretornar programa(s/n):   ",getchar());
   key=getchar();
   system("clear");
  }while(key=='s' || key=='S');
return 0;
}

void introducirnodo(){
	             nodo* nuevo=(nodo*) malloc(sizeof(nodo));
		     printf("\ningrese el dato en el nuevo nodo:  ");
		     scanf("%i",&nuevo->dato);
		     nuevo->siguiente=primero; //crear pila o lista con esta dos lineas de codigo
		     primero=nuevo;
                   }

void buscarnodo(){
	              int nb=0;
		      int enc=0;
	              nodo* actual=(nodo*) malloc(sizeof(nodo));
		      actual=primero;
		      printf("\ningrese el dato del nodo a buscar:   ");
		      scanf("%i",&nb);
		      if(primero!=NULL){
			                 while(actual!=NULL){
						              if(actual->dato==nb){
								                    printf("\nel nodo con el dato (%i) encontrado\n\n",nb);
										    enc=1;
							                          }
							      actual=actual->siguiente;
					                    }
					 printf("\n\n");
					 if(enc==0){
						     printf("\nnodo no encontrado\n\n");
					           }
		                       }
		      else{
			    printf("\nla pila se encuentra vacia\n");
		          }
                 }

void modificarnodo(){
	              int nb=0;
		      int enc=0;
	              nodo* actual=(nodo*) malloc(sizeof(nodo));
		      actual=primero;
		      printf("\ningrese el dato del nodo a buscar para modificar:   ");
		      scanf("%i",&nb);
		      if(primero!=NULL){
			                 while(actual!=NULL){
						              if(actual->dato==nb){
								                    printf("\nel nodo con el dato (%i) encontrado\n",nb);
										    printf("\ningrese el nuevo dato para el nodo:   ");
										    scanf("%i",&actual->dato);
										    printf("\nnodo modificado\n");
										    enc=1;
							                          }
							      actual=actual->siguiente;
					                    }
					 printf("\n\n");
					 if(enc==0){
						     printf("\nnodo no encontrado\n\n");
					           }
		                       }
		      else{
			    printf("\nla pila se encuentra vacia\n");
		          }
                    }


void eliminarnodo(){
	              int nb=0;
		      int enc=0;
	              nodo* actual=(nodo*) malloc(sizeof(nodo));
		      actual=primero;
		      nodo* anterior=(nodo*) malloc(sizeof(nodo));
		      anterior=NULL;
		      printf("\ningrese el dato del nodo a buscar para eliminar:   ");
		      scanf("%i",&nb);
		      if(primero!=NULL){
			                 while(actual!=NULL && enc!=1){
						                        if(actual->dato==nb){
								                              if(actual==primero){
									                                           primero=primero->siguiente;		                 
										                                 }
							                                      else{
								                                    anterior->siguiente=actual->siguiente;  
							                                          }
										              printf("\nel nodo ha sido eliminado con exito\n");
										              enc=1;
							                                     }
                                                                       anterior=actual;
							               actual=actual->siguiente;
					                             }
					 printf("\n\n");
					 if(enc==0){
						     printf("\nnodo no encontrado\n\n");
					           }
					 else{
					       free(anterior);
					     }
		                       }
		      else{
			    printf("\nla pila se encuentra vacia\n");
		          }
                   }


void desplegarnodo(){
	              nodo* actual=(nodo*) malloc(sizeof(nodo));
		      actual=primero;
		      if(primero!=NULL){
			                 while(actual!=NULL){
						              printf("\n%i",actual->dato);
							      actual=actual->siguiente;
					                    }
					 printf("\n\n");
		                       }
		      else{
			    printf("\nla pila se encuentra vacia\n");
		          }
                    }
