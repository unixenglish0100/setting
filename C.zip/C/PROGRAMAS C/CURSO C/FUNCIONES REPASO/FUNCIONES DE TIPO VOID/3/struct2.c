#include<stdio.h>
#define N 50
void cambio(char palabra[N]);
typedef struct{
char nombre[N];
char empleo[N];
int edad;

}usuario;
usuario a,b;
int main(){
system("clear");

printf("\ndigite nombre:   ");
fgets(a.nombre,N,stdin);
cambio(a.nombre);
printf("\ndigite empleo:   ");
fgets(a.empleo,N,stdin);
cambio(a.empleo);
printf("\ndigite edad:  ");
scanf("%i",&a.edad);
printf("\n\n");
while(getchar()!='\n');

printf("\ndigite nombre:   ");
fgets(b.nombre,N,stdin);
cambio(b.nombre);
printf("\ndigite empleo:   ");
fgets(b.empleo,N,stdin);
cambio(b.empleo);
printf("\ndigite edad:  ");
scanf("%i",&b.edad);

printf("\n\nel usuario 1 se llama %s su empleo es %s y tiene %i años",a.nombre,a.empleo,a.edad);
printf("\n\nel usuario 2 se llama %s su empleo es %s y tiene %i años\n\n",b.nombre,b.empleo,b.edad);
return 0;
}

void cambio(char palabra[N]){
	                      int i;
			      for(i=0;i<N;i++){
				                if(palabra[i]=='\n'){
							              palabra[i]='\0';
						                    }
			                      }
                            }

