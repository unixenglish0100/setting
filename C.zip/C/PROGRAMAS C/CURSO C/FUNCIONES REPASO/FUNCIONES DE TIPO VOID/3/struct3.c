#include<stdio.h>
#include<string.h>
#define N 50
void vacio();
void digitar();
void traducir();
void traduciendo(int op);
typedef struct{
char eng[N];
char esp[N];
int lleno;

}traductor;
traductor trad[N];
int main(){
system("clear");
int op;
char key;
key='s';
do{
    do{
        printf("********************************************");
        printf("\n\t\tMENU");
        printf("\n********************************************");
        printf("\n\t1. INGRESAR DATO");
        printf("\n\t2. TRADUCIR\n:");
        scanf("%i",&op);	
    }while (op<1 || op>2);    
    switch(op){
	        case 1: digitar(); break;
		case 2: traducir(); break;
              }  
    printf("\nretornar programa (s/n):   ",getchar());
    key=getchar();
    system("clear");
  }while(key=='s' || key=='S');
	

return 0;
}

void vacio(){
	     int i;
             for(i=0;i<N;i++){
		               trad[i].lleno=0;
	                     }
            }

void digitar(){
	       int i,j;
	       j=0;
	       for(i=0;i<N && j==0;i++){
		                         if(trad[i].lleno==0){
					                        printf("\ndigite palabra en ingles:    ");
					                        scanf("%s",&trad[i].eng);
							        printf("\ndigite palabra en español:   ");
							        scanf("%s",&trad[i].esp);
								trad[i].lleno=1;
								j=1;
				                             }
	                               }  
              }

void traducir(){
	         int op;
                 do{
                     printf("\n\n********************************************");
                     printf("\n\t\tMENU");
                     printf("\n********************************************");
                     printf("\n\t1. TRADUCIR DE INGLES A ESPAÑOL");
                     printf("\n\t2. TRADUCIR DE ESPAÑOL A INGLES\n:");
                     scanf("%i",&op);	
                    }while (op<1 || op>2);    
                  switch(op){
 	                      case 1: traduciendo(op); break;
		              case 2: traduciendo(op); break;
                            }  
	       }

void traduciendo(int op){
	                  int i,c,temp;
			  char aux[N];
			  temp=0;
			  if(op==1){
				     printf("\ndigite palabra en ingles:   ");
				     scanf("%s",&aux);
				     for(i=0;i<N && temp==0;i++){
				                                   c=strcmp(aux,trad[i].eng);
								   if(c==0){
					                                     printf("\nla traducion de %s en español es %s\n\n",trad[i].eng,trad[i].esp);
									     temp=1;
				                                            } 
				                                 }  
			           }
			  else{
				  printf("\ndigite palabra en español:   ");
				  scanf("%s",&aux);
				  for(i=0;i<N && temp==0;i++){
				                               c=strcmp(aux,trad[i].esp);
						               if(c==0){
					                                 printf("\nla traducion de %s en ingles es %s\n\n",trad[i].esp,trad[i].eng);
							                 temp=1;
				                                       } 
				                              }  
			      }
                        }



