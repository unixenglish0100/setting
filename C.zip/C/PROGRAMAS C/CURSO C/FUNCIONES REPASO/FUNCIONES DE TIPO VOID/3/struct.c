#include<stdio.h>
#include<string.h>
#define N 50
typedef struct{
int paginas;
char nombre[N];
float precio;

}libro;

libro JT,MX;
int main(){
system("clear");

strcpy(JT.nombre,"el juego de tronos");
JT.paginas=300;
JT.precio=23.52;

strcpy(MX.nombre,"matrix");
MX.paginas=600;
MX.precio=30.25;

printf("\nel nombre del libro es %s tiene %i paginas y tiene un valor de %f\n",JT.nombre,JT.paginas,JT.precio);
printf("el nombre del libro es %s tiene %i paginas y tiene un precio de %f\n\n",MX.nombre,MX.paginas,MX.precio);


return 0;	
}
