#include<stdio.h>
#define N 50
typedef struct{
int paginas;
char nombre[N];
float precio;

}libro;

libro JT[N];
int main(){
system("clear");
int i;
for(i=0;i<10;i++){
	           JT[i].precio=25+1;
		   printf("\nel precio de la estructura %i es %f",i+1,JT[i].precio);
                 }
printf("\n\n");


return 0;
}
