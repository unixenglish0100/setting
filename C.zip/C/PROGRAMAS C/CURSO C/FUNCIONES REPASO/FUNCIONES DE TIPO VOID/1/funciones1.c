#include<stdio.h>
void mayor(int a,int b);
int main(){
int x,y;
x=3;
y=20;
system("clear");

mayor(x,y);

return 0;
}


void mayor(int a,int b){
                           if(a>b){
                                     printf("\n\nel mayor es %i\n\n",a);
                                  }
                           else{
                                 printf("\n\nel mayor es %i\n\n",b);
                               }
                       }


