#include<stdio.h>
void cambio(int *a,int *b,int *c);
int main(){
system("clear");

int x,y,z;
x=34;
y=292;
z=2000;

cambio(&x,&y,&z);

printf("\n\nx = %i    y = %i    z = %i\n\n",x,y,z);


return 0;
}

void cambio(int *a,int *b,int *c){
                                   int aux;
                                   aux=*a;
                                   *a=*b;
                                   *b=aux;

                                   *c=4000;                                   
                                 }
