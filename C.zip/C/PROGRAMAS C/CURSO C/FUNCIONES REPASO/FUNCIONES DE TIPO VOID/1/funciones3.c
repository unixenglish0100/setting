#include<stdio.h>
void par();
int main(){
system("clear");

par();

return 0;

}

void par(){
            int a,par;
            printf("\n\ndigite numero:   ");
            scanf("%i",&a);
            par=a%2;
            if(par==0){
                        printf("\n\nel numero %i es par\n\n",a);
                      }
            else{
                  printf("\n\nel numero %i es impar\n\n",a);
                }

          }


