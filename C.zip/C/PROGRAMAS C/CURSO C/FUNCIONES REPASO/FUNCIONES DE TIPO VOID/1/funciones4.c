#include<stdio.h>
void primo();
int main(){
system("clear");

primo();

return 0;

}

void primo(){
              int a,i,j,aux;
              printf("\n\ndigite numero:    ");
              scanf("%i",&a);
              j=0;
              for(i=2;i<a && j!=1;i++){
                                        aux=a%i;
                                        if(aux==0){
                                                     j=1;
                                                   }
                                       }
               if(j==0){
                         printf("\n\nel numero %i es primo\n\n",a);
                       }
               else{
                     printf("\n\nel numero %i no es primo\n\n",a);
                   }
            }

