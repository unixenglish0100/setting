#include<stdio.h>
void suma();
void resta();
void multiplicacion();
void division();
int main(){
system("clear");
int o;
char c;
c='s';


do{
printf("\n\n**************************************************");
printf("\n             CALCULADORA");
printf("\n***************************************************");
printf("\n1.  SUMA");
printf("\n2.  RESTA");
printf("\n3.  MULTIPLICACION");
printf("\n4.  DIVISION");
printf("\n***************************************************");
printf("\n\ndigite opcion de operacion:    ");
scanf("%i",&o);

switch(o){
          case 1: suma(); break;
          case 2: resta(); break;
          case 3: multiplicacion(); break;
          case 4: division(); break;
          default: printf("\n\nnumero no valido"); 
         }

printf("\n\nRETORNAR PROGRAMA (S/N):    ",getchar());
c=toupper(getchar());
system("clear");

}while(c=='s' || c=='S');


return 0;
}

void suma(){
             int a,b,i,sum;
             sum=0;
             printf("\n\ndigite cuantos numeros quiere sumar:   ");
             scanf("%i",&a);
             for(i=1;i<=a;i++){
                                printf("\n\ndigite %i numero:   ",i);
                                scanf("%i",&b);
                                sum+=b;
                              }
             printf("\n\nel resultado de la suma es %i\n\n",sum);
           }

void resta(){
             int a,b,res;
             res=0;
             printf("\n\ndigite primer numero:   ");
             scanf("%i",&a);
             printf("\n\ndigite segundo numero:   ");
             scanf("%i",&b);
             res=a-b;
             printf("\n\nel resultado de la resta %i - %i = %i\n\n",a,b,res);
           }

void multiplicacion(){
                      int a,b,i,mul;
                      mul=1;
                      printf("\n\ndigite cuantos numeros quiere multiplicar:   "); 
                      scanf("%i",&a);
                      for(i=1;i<=a;i++){
                                        printf("\n\ndigite %i numero:    ",i);
                                        scanf("%i",&b);
                                        mul*=b;
                                       }
                      printf("\n\nel resultado de la multiplicacion es %i\n\n",mul);  
                     }

void division(){
                float a,b;
                float div;
                printf("\n\ndigite primer numero:   ");
                scanf("%f",&a);
                printf("\n\ndigite segundo numero:   ");
                scanf("%f",&b);
                div=a/b;
                printf("\n\nel resultado de la division %f / %f = %f\n\n",a,b,div);
               }


