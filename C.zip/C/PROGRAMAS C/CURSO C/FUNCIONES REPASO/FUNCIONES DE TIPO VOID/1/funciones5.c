#include<stdio.h>
void factorial();
int main(){
system("clear");

factorial();

return 0;
}


void factorial(){
                  int a,i,fac;
                  printf("\n\ndigite numero:    ");
                  scanf("%i",&a);
                  fac=1;
                  for(i=1;i<=a;i++){
                                    fac=fac*i; 
                                   }
                  printf("\n\nel factorial de %i es %i\n\n",a,fac);
                }


