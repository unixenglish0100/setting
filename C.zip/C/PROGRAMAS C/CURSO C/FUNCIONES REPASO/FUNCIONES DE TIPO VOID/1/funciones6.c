#include<stdio.h>
void fibonacci();
int main(){
system("clear");

fibonacci();

return 0;
}

void fibonacci(){
                  int a,b,c,i,fib;
                  b=0;
                  c=1;
                  printf("\n\ndigite numero:     ");
                  scanf("%i",&a);
                  if(a==1){
                            printf("0");
                          }
                  else{
                        printf("0, 1, ");
                      }

                  for(i=3;i<=a;i++){
                                     fib=b+c;
                                     printf("%i, ",fib);
                                     b=c;
                                     c=fib;
                                   }
                   printf("\n\n");
                }


