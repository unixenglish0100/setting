#include<stdio.h>
#include<unistd.h>
void cronometro();
int main(){
system("clear");

cronometro();

return 0;
}

void cronometro(){
                   int hor,min,seg;
                   for(hor=0;hor<24;hor++){
                                            for(min=0;min<60;min++){
                                                                     for(seg=0;seg<60;seg++){
                                                                                              printf("\n%02i:%02i:%02i",hor,min,seg);
                                                                                              sleep(1);
                                                                                            }
                                                                   }
                                          }
                 }


