#include<stdio.h>
void multiplicar();
int main(){
system("clear");

multiplicar();

return 0;
}

void multiplicar(){
                    int i,j;
                    for(i=1;i<=9;i++){
                                       for(j=1;j<=10;j++){
                                                           printf("\n%i * %i = %i",i,j,i*j); 
                                                         }
                                       printf("\n");
                                     }
                  }


