#include<stdio.h>
void listar();
int main(){

system("clear");

listar();

return 0;

}

void listar(){
               int a,b,i;
               printf("\n\ndigite primer numero:   ");
               scanf("%i",&a);
               do{
                   printf("\n\ndigite segundo numero:    ");
                   scanf("%i",&b);
                 }while(a>=b);
               for(i=a;i<=b;i++){
                                  printf("%i, ",i);
                                 }
               printf("\n\n");
             }


