#include<stdio.h>
#define N 10
void comparar(int *c);
void listar(int *l);
int main(){
system("clear");
int v[N]={4,2,7,1,3};

comparar(v);
listar(v);
return 0;
}

void comparar(int *c){
	               int i,j,aux;
		       for(i=0;i<5;i++){
			                 for(j=i;j<5;j++){
						           if(*(c+i)>*(c+j)){
								              aux=*(c+i);
									      *(c+i)=*(c+j);
									      *(c+j)=aux;
							                    }
					                 }
		                       }
                     }

void listar(int *l){
	             int i;
		     for(i=0;i<5;i++){
			               printf("%i, ",*(l+i));
		                     }
		     printf("\n\n");
                   }
