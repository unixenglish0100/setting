#include<stdio.h>
#define N 20
void digitar(int d[N]);
void listar(int l[N]);
int main(){
system("clear");
int v[N];

digitar(v);
listar(v);

return 0;
}

void digitar(int d[N]){
	                printf("\ndigite primer numero:    ");
			scanf("%i",&d[0]);
			printf("\ndigite segundo numero:   ");
			scanf("%i",&d[1]);
			printf("\ndigite tercer numero:    ");
			scanf("%i",&d[2]);
                      }

void listar(int l[N]){
	               int i;
		       for(i=0;i<3;i++){
			                 printf("%i,  ",l[i]);
				       }
		       printf("\n\n");
                     }

