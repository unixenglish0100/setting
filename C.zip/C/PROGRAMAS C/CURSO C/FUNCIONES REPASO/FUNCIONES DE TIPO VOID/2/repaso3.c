#include<stdio.h>
#define N 10
void sorteo(int *s);
void listar(int *l);
int main(){
system("clear");
int v[N]={0,0,0,0,0,0};

sorteo(v);
listar(v);

return 0;
}

void sorteo(int *s){
	             int i,aux;
		     srand(time(NULL));
		     for(i=0;i<10;i++){
			                aux=rand()%6; 
					switch(aux){
						     case 0: *(s+aux)+=1; break;
					             case 1: *(s+aux)+=1; break;
					             case 2: *(s+aux)+=1; break;	
				                     case 3: *(s+aux)+=1; break;
				                     case 4: *(s+aux)+=1; break;
						     case 5: *(s+aux)+=1; break;
					           }
		                      }
                   }

void listar(int *l){
	             int i;
		     float est;		     
		     for(i=0;i<6;i++){
			               est=(*(l+i)*100)/10.0;
				       printf("\nel numero %i tiene de porcentaje %f y salio %i veces\n\n",i,est,*(l+i));
		                     }
                   }
