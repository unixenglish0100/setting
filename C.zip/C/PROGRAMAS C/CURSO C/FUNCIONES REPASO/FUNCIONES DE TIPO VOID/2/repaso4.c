#include<stdio.h>
#define N 10
void matrix(int m[N][N]);
void listar(int l[N][N]);
int main(){
system("clear");
int v[N][N];
matrix(v);
listar(v);

return 0;
}

void matrix(int m[N][N]){
	                  int i,j,aux;
			  srand(time(NULL));
			  for(i=0;i<5;i++){
				            for(j=0;j<5;j++){
						              aux=rand()%10;
							      m[i][j]=aux;
					                    }
			                  }
                        }

void listar(int l[N][N]){
	                  int i,j;
			  for(i=0;i<5;i++){
				            for(j=0;j<5;j++){
						              printf("%i  ",l[i][j]);
					                    }
					    printf("\n");
			                  }
			  printf("\n\n");
                        }
