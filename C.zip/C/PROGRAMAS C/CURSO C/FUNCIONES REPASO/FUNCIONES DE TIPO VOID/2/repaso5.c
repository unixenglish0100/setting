#include<stdio.h>
#define N 10
void digitar(int d[N][N]);
void comparar(int c[N][N],int c1[N][N]);
int main(){
system("clear");
int v[N][N];
int v1[N][N];

digitar(v);
digitar(v1);
comparar(v,v1);
return 0;
}

void digitar(int d[N][N]){
	                   int i,j;
			   for(i=0;i<2;i++){
				             for(j=0;j<2;j++){
						               printf("\ndigite numero:   ");
							       scanf("%i",&d[i][j]);
					                     }
			                   }
                         }

void comparar(int c[N][N],int c1[N][N]){
	                                int i,j,k;
					k=0;
                                        for(i=0;i<2 && k==0;i++){
				                                  for(j=0;j<2 && k==0;j++){
						                                            if(c[i][j]!=c1[i][j]){
									                                            k=1;
									                                         }
					                                                  }
			                                         }
				        if(k==0){
						  printf("\nlas dos matrices son iguales\n\n");
					        }	
					else{
				              printf("\nlas dos matrices son distintas\n\n");
					    }
                                       }  






