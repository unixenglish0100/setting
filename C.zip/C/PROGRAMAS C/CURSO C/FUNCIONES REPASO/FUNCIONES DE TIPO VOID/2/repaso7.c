#include<stdio.h>
#define N 50
void cambio(char *c);
int main(){
system("clear");
char v[N]="la cosina de la casa esta limpia y es grande";

cambio(v);
printf("\nla frase es %s\n\n",v);

return 0;
}

void cambio(char *c){
	              int i;
		      for(i=0;i<N;i++){
			                if(*(c+i)=='a'){
						         *(c+i)=' ';
					               }
		                      }
                    }
