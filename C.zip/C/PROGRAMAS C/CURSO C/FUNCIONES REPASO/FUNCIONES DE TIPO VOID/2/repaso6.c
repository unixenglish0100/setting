#include<stdio.h>
#define N 50
void cambio(char *c);
int main(){
system("clear");
char v[N];

printf("\ndigite frase:   ");
fgets(v,N,stdin);

cambio(v);

printf("la frase es %s\n",v);
return 0;
}

void cambio(char *c){
	             int i;
	             for(i=0;i<N;i++){
		                       if(*(c+i)=='\n'){
					                  *(c+i)='\0';
				                       }
	                             }
                     }

              
