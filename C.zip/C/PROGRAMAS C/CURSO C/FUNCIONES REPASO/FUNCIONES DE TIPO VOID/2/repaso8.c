#include<stdio.h>
#include<string.h>
#define N 50
void digitar(char *d);
void comparar(char *c,char *c1);
int main(){
system("clear");
char v[N];
char v1[N];

digitar(v);
digitar(v1);
printf("\n\n");
comparar(v,v1);

return 0;
}

void digitar(char *d){
	               printf("\ndigite frase:    ");
		       fgets(d,N,stdin);
                     }

void comparar(char *c,char *c1){
				 if(strcmp(c,c1)==0){
					              printf("\nlas dos cadenas son iguales\n\n");
				                    }
				 else{
					printf("\nlas dos cadenas son distintas\n\n");
				     }
                               }
