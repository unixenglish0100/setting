//programa sobre funciones liste el factorial de dos numeros
#include<stdio.h>
int factorial();
int main(){
system("clear");
int x,y;
int pri1,pri2;
printf("\n\ndigite primer numero:    ");
scanf("%i",&x);
printf("\ndigite segundo numero: ");
scanf("%i",&y);


pri1=factorial(x);
pri2=factorial(y);

printf("\n\nel factorial de %i es %i\n\n",x,pri1);
printf("\n\nel factorial de %i es %i\n\n",y,pri2);

return 0;
}

int factorial(int a){
                      int i,aux;
                      aux=1;
                      for(i=1;i<=a;i++){
                                         aux*=i;
                                       } 
                      return aux;
                    }
