//programa sobre funciones prueba
#include<stdio.h>
int prueba(int a);
int main(){
system("clear");

int x,y,fac1,fac2;
char c;
c='s';
do{
    printf("\n\ndigite primer numero:   ");
    scanf("%i",&x);
    printf("\ndigite segundo numero:   ");
    scanf("%i",&y);

    fac1=prueba(x);
    fac2=prueba(y);

    printf("\n\nel factorial de %i es %i",x,fac1);
    printf("\n\nel factorial de %i es %i\n\n",y,fac2);

    printf("\n\nretornar programa(s/n):   ",getchar());
    c=getchar();
    system("clear");    

   }while(c=='s' || c=='S');
return 0;
}

int prueba(int a){
                   int i,fac;
                   fac=1;
                   for(i=1;i<=a;i++){
                                      fac*=i;
                                    }
                   return fac;
                 }
