//programa sobre funciones que dice si dos numeros son primos
#include<stdio.h>
int primo(int a);
int main(){
system("clear");

int x,y,pri1,pri2;
printf("\n\ndigite primer numero:   ");
scanf("%i",&x);
printf("\ndigite segundo numero:   ");
scanf("%i",&y);

pri1=primo(x);
pri2=primo(y);

if(pri1==0){
            printf("\n\nel numero %i es primo\n\n",x);
           }
else{
     printf("\n\nel numero %i no es primo\n\n",x);
    }

if(pri2==0){
            printf("\n\nel numero %i es primo\n\n",y);
           }
else{
     printf("\n\nel numero %i no es primo\n\n",y);
    }




return 0;

}

int primo(int a){
                 int i,j,aux;
                 j=0;
                 for(i=2;i<a && j!=1;i++){
                                           aux=a%i;
                                           if(aux==0){
                                                       j=1;
                                                     }
                                         }
                 return j;
                }
