#include<stdio.h>
int main(){
int i;
//system("clear");

printf("\n\ndigite numero:   ");
scanf("%i",&i);

printf("\nel numero es %i\n",i);




return 0;
}
