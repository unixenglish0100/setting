# include "stdio.h"
# include "ncurses.h"
# include "ctype.h"
# include "string.h"
int main (void)
{
   char clave[60];
   char nom[60],ap[60];
   char s,w;
   w='\0';
   int j=0;
   system("clear");
   do{
       printf("\n\n\t************************************************************");
       printf("\n\n\t\t\tPASSWORD");
       printf("\n\n\t************************************************************");
       printf("\n\n\t\tDIGITE PASSWORD:    ");
       scanf("%s",clave);
       j=strcmp(clave,"bien");
       system("clear");
    }while(j!=0);
  system("clear");
  do{
      printf("\n\n\t*************************************************************");
      printf("\n\n\t\t\tSOFTWARE STRCAT");
      printf("\n\n\t*************************************************************");
      printf("\n\n\t\t\tDIGITE NOMBRE:    ");
      scanf("%s",nom);
      printf("\n\n\t\t\tDIGITE APELLIDO:    ");
      scanf("%s",ap);
      strcat(nom,ap);
      printf("\n\n\t\tEL NOMBRE ES %s",nom);
      printf("\n\n\t\tRETORNAR PROGRAMA (S/N):    ",getchar());
      w=toupper(getchar());
      system("clear");
   }while(w!='N');
 printf("\n\nDIGITE TECLA EN LA TERMINACION DEL SOFTWARE:    ",getchar());
 s=getchar();
 system("clear");
 return 0;
}
