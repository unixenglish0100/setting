# include "stdio.h"
# include "ncurses.h"
# include "ctype.h"
# include "string.h"
int main (void)
{
  char clave[60];
  char s,w;
  w='\0';
  int j=0;
  char p1[60];
  char p2[60];
  system("clear");
  do{
     printf("\n\n\t**************************************************************");
     printf("\n\n\t\t\tPASSWORD");
     printf("\n\n\t**************************************************************");
     printf("\n\n\t\t\tDIGITE PASSWORD:    ");
     scanf("%s",clave);
     j=strcmp(clave,"bien");
     system("clear");
    }while(j!=0);
  system("clear");
  do{
      printf("\n\n\t*************************************************************");
      printf("\n\n\t\t\tSOFTWARE STRCPY");
      printf("\n\n\t*************************************************************");
      printf("\n\n\t\t\tDIGITE PRIMER PALABRA:    ");
      scanf("%s",p1);
      printf("\n\n\t\t\tDIGITE SEGUNDA PALABRA:    ");
      scanf("%s",p2);
      strcpy(p1,p2);
      printf("\n\n%51s",p1);
      printf("\n\n\t\tRETORNAR PROGRAMA (S/N):    ",getchar());
      w=toupper(getchar());
      system("clear");
   }while(w!='N');
 printf("\n\nDIGITE TECLA EN LA TERMINACION DEL SOFTWARE:    ",getchar());
 s=getchar();
 system("clear");
 return 0;
}
