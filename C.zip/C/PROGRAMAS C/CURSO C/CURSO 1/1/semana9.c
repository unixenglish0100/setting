// digitar numero y decir que dia de la semana es

# include <stdio.h>
int main (){

int x;


system("clear");

printf("\n\nDigite numero:   ");
scanf("%i",&x);

if(x==1){
          printf("\n\nlunes\n\n");
        }
else if(x==2){
               printf("\n\nmartes\n\n");
             }
else if(x==3){
               printf("\n\nmiercoles\n\n");
             }
else if(x==4){
               printf("\n\njueves\n\n");
             }
else{
     printf("\n\nnumero no valido\n\n");
    }

return 0;


} 
