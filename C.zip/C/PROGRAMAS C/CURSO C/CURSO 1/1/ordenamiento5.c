// ordenamiento por metodo de burbuja

# include <stdio.h>
int main (){

int x,y,aux;

system("clear");


printf("\n\ndigite primer numero:   ");
scanf("%i",&x);

printf("\n\ndigite segundo numero:   ");
scanf("%i",&y);

aux = x;
x = y;
y = aux;


printf("\n\nel valor de x es %i\n",x);
printf("\n\nel valor de y es %i\n\n",y);

return 0;


}
