// ampliacion de conocimiento

# include <stdio.h>
# include <math.h>

int main(){

int x,y;

x=2;
y=2;

system("clear");

// operaciones matematicas
x += y;  // x=x+y;
printf("\n\nla suma de x + y = %i\n\n",x);


// libreria math
x=pow(x,y);
printf("\n\nel valor de x elevado a y es %i\n\n",x);

x=sqrt(x);
printf("\n\nel valor de raiz cuadrada de x es %i\n\n",x);

// operadores de incremento
x++;
printf("\n\nel valor de x++ = %i\n\n",x);

x--; 
printf("\nel valor de x-- = %i\n\n",x);

return 0;

}


