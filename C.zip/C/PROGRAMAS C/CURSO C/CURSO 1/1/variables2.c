// variables 2

# include <stdio.h>
int main (){

int x,y,z;
char c;

x= 20;
y= 40;
z= 60;
c='e';

printf("\n\nla variable x es %i",x);
printf("\nla variable y es %i",y);
printf("\nla variable z es %i",z);
printf("\nla variable c es %c\n\n",c);

return 0;

}
