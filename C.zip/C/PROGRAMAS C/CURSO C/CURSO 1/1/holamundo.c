#include<stdio.h>

int main (){
system("clear");
printf("\nhola mundo\n\n");

return 1;

}
