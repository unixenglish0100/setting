// comparacion numeros

# include <stdio.h>
int main (){

int x,y,z;
int max,min;

system("clear");


printf("\n\nDigite primer numero:  ");
scanf("%i",&x);

printf("\n\nDigite segundo numero:  ");
scanf("%i",&y);

printf("\n\nDigite tercer numero:  ");
scanf("%i",&z);

if(x>y){
         if(x>z){
                 max=x;
                }
         else{
               max=z;
             }
       }

else{
      if(y>z){
               max=y;
             }
      else{
             max=z;
          }
     } 

printf("\n\nEl numero mayor es %i\n\n",max);

if(x<y){
         if(x<z){
                 min=x;
                }
         else{
               min=z;
             }
       }

else{
      if(y<z){
               min=y;
             }
      else{
             min=z;
          }
     }

printf("\n\nel numero menor es %i\n\n",min);

return 0; 

}


