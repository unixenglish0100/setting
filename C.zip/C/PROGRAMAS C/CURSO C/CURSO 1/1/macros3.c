// operaciones con variables

# include <stdio.h>
# define PI 3.1416
int main(){

int y;
float x;
x= PI;

printf("\n\nEl valor de x es %f\n\n",x);

printf("\n\nDigite numero:  ");
scanf("%i",&y);

printf("\n\nEl valor de y es %i\n",y);


x = x*y;
printf("\n\nel nuevo valor de x es %f\n\n",x);


return 0;
}

