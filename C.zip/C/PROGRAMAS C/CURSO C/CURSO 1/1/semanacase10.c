// programa semana case
# include <stdio.h>
int main (){

int x;

system("clear");

printf("\n\ndigite numero del 1 al 4:    ");
scanf("%i",&x);

switch(x) {
            case 1: printf("\n\nlunes\n\n"); break;
            case 2: printf("\n\nmartes\n\n"); break;
            case 3: printf("\n\nmiercoles\n\n"); break;
            case 4: printf("\n\njueves\n\n"); break;
            default: printf("\n\nnumero no valido\n\n"); break;
          }

return 0;
}
