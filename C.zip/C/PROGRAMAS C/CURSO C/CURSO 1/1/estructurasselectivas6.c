// estructuras selectivas

# include <stdio.h>
int main(){

int x,y;
x = 9;

system("clear");
printf("\n\nintenta acertar el numero.  \n\ndigite numero del 1 al 10:   ");
scanf("%i",&y);

if(x==y){
         printf("\n\nacerto el numero\n\n");
        }
else{
      printf("\n\nno acertaste el numero\n\n");
    }

return 0;

}
