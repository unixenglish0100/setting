// numero par

# include "stdio.h"
int main (){

int x,y;

system("clear");

printf("\n\nDigite numero:   ");
scanf("%i",&x);

y=x%2;

if(y==0){
          printf("\n\nel numero %i es par\n\n",x);
         }

else{
     printf("\n\nel numero %i es impar\n\n",x);
    }

return 0;
}
