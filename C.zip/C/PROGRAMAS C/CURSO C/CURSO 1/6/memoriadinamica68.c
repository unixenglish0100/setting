#include<stdio.h>
#include<stdlib.h>
int main(){
system("clear");
int i,N;
int *v;

printf("\ndigite numero pal vector:   ");
scanf("%i",&N);

v=(int*) malloc(N*sizeof(int));
if(v==0){
	  printf("\nno se ha podido reservar la memoria\n");
        }
else{
      for(i=0;i<N;i++){
	                *(v+i)=i;
                      }	
      for(i=0;i<N;i++){
	                printf("%i, ",*(v+i));
                      }
      printf("\n\n");
    }

printf("\ndigite numero pal vector:   ");
scanf("%i",&N);

v=(int*) malloc(N*sizeof(int));
if(v==0){
	  printf("\nno se ha podido reservar la memoria\n");
        }
else{
      for(i=0;i<N;i++){
	                *(v+i)=i;
                      }	
      for(i=0;i<N;i++){
	                printf("%i, ",*(v+i));
                      }
      printf("\n\n");
    }
return 0;
}
