#include<stdio.h>
typedef struct{
int matematicas;
int ingles;
int fisica;
}materias;

void darnota(materias not[]);

int main(){
system("clear");
materias not[3];

darnota(not);

return 0;
}

void darnota(materias not[]){
                              printf("\ncual es la nota de matematicas:    ");
			      scanf("%i",&not[0].matematicas);
                              printf("\ncual es la nota de ingles:    ");
			      scanf("%i",&not[0].ingles);
                              printf("\ncual es la nota de fisica:    ");
			      scanf("%i",&not[0].fisica);

			      printf("\nla nota de matematicas es %i\n",not[0].matematicas);
			      printf("\nla nota de ingles es %i\n",not[0].ingles);
			      printf("\nla nota de fisica es %i\n",not[0].fisica);
                             
                          }
