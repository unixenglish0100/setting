#include<stdio.h>
#include<stdlib.h>
#include<time.h>

void aleatorio(int *a,int M);
int main(){
system("clear");

int i,j,k;
int N=10;
int *v;

v=(int*) malloc(N*sizeof(int));
if(v==NULL){
	     printf("\nno hay espacion en memoria\n");
           }
else{
      aleatorio(v,N);	
      for(i=0;i<N;i++){
	                j=i+1;
			while(j<N){
				    if(*(v+i)==*(v+j)){
						        for(k=j;k+1<N;k++){
								            *(v+k)=*(v+k+1);
							                  } 
							N--;
						      }
                                    else{
					  j++;  
				        }
			          }
                      } 
      v=(int*) realloc(v,N*sizeof(int));
      if(v==NULL){
                   printf("\nno hay espacion en memoria\n");
                 }
      else{
	    for(i=0;i<N;i++){
		              printf("%i, ",*(v+i));
	                    }
	    printf("\n");
          }
    }


return 0;
}

void aleatorio(int *a,int M){
                              int i;
			      srand(time(NULL));
			      for(i=0;i<M;i++){
			                       *(a+i)=rand()%3;
					       printf("%i, ",*(a+i)); 
			                      }
			      printf("\n\n");
                            } 
