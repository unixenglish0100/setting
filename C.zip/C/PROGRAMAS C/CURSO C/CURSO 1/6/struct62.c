#include<stdio.h>
#include<string.h>
#define N 50
typedef struct{
char nombre[N];
int paginas;
float precio;

}libros;

libros JT[10];

int main(){
system("clear");
int i;

for(i=0;i<10;i++){
	          JT[i].precio=25+1;
	          printf("\nel precio de la estructura %i es %f",i,JT[i].precio);	  
                }


return 0;
}
