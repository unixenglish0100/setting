#include<stdio.h>
#include<string.h>
#define N 50

typedef struct{
char nombre_lib[N];
char autor[N];
int lleno_lib;
}libro;

typedef struct{
char nombre_bi[N];
libro lib[10];
int lleno_bi;
}biblioteca;

biblioteca bi[3];

void vacio();
void cambio(char palabra[N]);
void anadebi();
void anadelib();
void consulta();
int main(){
system("clear");
int op;
char key;
key='s';
vacio();
do{
    do{
        printf("\nelige una opcion a realizar:   ");
        printf("\n1. añadir una nueva biblioteca");
        printf("\n2. añadir un libro a una biblioteca");
        printf("\n3. consultar un libro\n:");
        scanf("%i",&op);	
    }while(op<1 || op>3);
    switch(op){
	        case 1: anadebi(); break;
	        case 2: anadelib(); break;
	        case 3: consulta(); break;		
              }
    printf("\nretornar programa (s/n):   ",getchar());
    key=getchar();
    system("clear");    
}while(key=='s' || key=='S');

return 0;
}

void vacio(){
	      int i,j;
	      for(i=0;i<3;i++){
		                bi[i].lleno_bi=0;
	                        for(j=0;j<10;j++){
		                                    bi[i].lib[j].lleno_lib=0;
	                                         }
			      }	
            }

void cambio(char palabra[N]){
	                      int i;
			      for(i=0;i<N;i++){
				                if(palabra[i]=='\n'){
							              palabra[i]='\0';
						                    }
			                      }
                            }

void anadebi(){
	        int i,aux;
		aux=0;
		for(i=0;i<3 && aux==0;i++){
			                    if(bi[i].lleno_bi==0){
					                           printf("\nintroduce un nombre para la biblioteca:   ");
							           scanf("%s",&bi[i].nombre_bi);
								   //cambio(bi[i].nombre_bi);
							           bi[i].lleno_bi=1;
							           aux=1;
				                                 }
		                          }
		if(aux==0){
			    printf("\n\nno queda ningun hueco libre para una nueva biblioteca\n");
		          }
              }

void anadelib(){
	         int i,op,aux;
		 aux=0;
		 for(i=0;i<3;i++){
			           if(bi[i].lleno_bi==1){
					                  printf("\n%i. %s",i,bi[i].nombre_bi);
				                        }
		                 }
		 printf("\n:");
		 scanf("%i",&op);
		 for(i=0;i<10 && aux==0;i++){
			                      if(bi[op].lib[i].lleno_lib==0){
					                                      while(getchar()!='\n');
					                                      printf("\nintroduce el nombre del libro:   ");
								              fgets(bi[op].lib[i].nombre_lib,N,stdin);
								              cambio(bi[op].lib[i].nombre_lib);
                                                                   
					                                      while(getchar()!='\n');
					                                      printf("\nintroduce el autor del libro:   ");
								              fgets(bi[op].lib[i].autor,N,stdin);
								              cambio(bi[op].lib[i].autor);
								              
                                                                              printf("\nnombre : %s          autor : %s",bi[op].lib[i].nombre_lib,bi[op].lib[i].autor);
								              bi[op].lib[i].lleno_lib=1;
                                                                              aux=1;                                  
 									      
				                                             }
		                            }   
               }

void consulta(){
	         int op,i,j,aux;
		 aux=1;
		 char buscar[N];
		 do{
		     printf("\nque quiere buscar nombre libro o nombre autor:    ");
	             printf("\n1. nombre libro");
	             printf("\n2. nombre autor\n:");
	             scanf("%i",&op);	     
		 }while (op<1 || op>2);
		 switch(op){
			     case 1: while(getchar()!='\n');
				     printf("\nintroduce el nombre del libro:   ");
                                     fgets(buscar,N,stdin);
				     cambio(buscar);
				     for(i=0;i<3;i++){
					              //aux=1;
					              for(j=0;j<10;j++){
							                 aux=strcmp(buscar,bi[i].lib[j].nombre_lib);
									 if(aux==0){
										     printf("\nel libro %s se encuentra en la biblioteca %s\n",buscar,bi[i].nombre_bi);
										     printf("\nel autor del libro es %s\n",bi[i].lib[j].autor);
									           }
						                       }
				                     }
				     break;
				    
			     case 2: while(getchar()!='\n');
				     printf("\nintroduce el nombre del autor:   ");
                                     fgets(buscar,N,stdin);
				     cambio(buscar);
				     for(i=0;i<3;i++){
					              //aux=1;
					              for(j=0;j<10;j++){
							                 aux=strcmp(buscar,bi[i].lib[j].autor);
									 if(aux==0){
										     printf("\nel libro %s se encuentra en la biblioteca %s\n",bi[i].lib[j].nombre_lib,bi[i].nombre_bi);
										    }
						                       }
				                     }
				     break; 
		              		     
		           }
               }





