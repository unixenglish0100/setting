#include<stdio.h>
#define N 50
void cambio(char palabra[N]);

typedef struct{
char nombre[N];
char empleo[N];
int edad;

}usuario;

usuario u1,u2;
int main(){
system("clear");

printf("\n\ndigite nombre:   ");
fgets(u1.nombre,N,stdin);
cambio(u1.nombre);
printf("\ndigite empleo:    ");
fgets(u1.empleo,N,stdin);
cambio(u1.empleo);
printf("\ndigite edad:   ");
scanf("%i",&u1.edad);
while(getchar()!='\n');

printf("\n\ndigite nombre:   ");
fgets(u2.nombre,N,stdin);
cambio(u2.nombre);
printf("\ndigite empleo:    ");
fgets(u2.empleo,N,stdin);
cambio(u2.empleo);
printf("\ndigite edad:   ");
scanf("%i",&u2.edad);
printf("\nel nombre del primer usuario es %s su empleo es %s y tiene %i años\n",u1.nombre,u1.empleo,u1.edad);
printf("\nel nombre del segundo usuario es %s su empleo es %s y tiene %i años\n",u2.nombre,u2.empleo,u2.edad);

return 0;
}

void cambio(char palabra[N]){
	                      int i;
		       	      for(i=0;i<N;i++){
			                        if(palabra[i]=='\n'){
					                              palabra[i]='\0';
					                             }
			                       }
                            }
