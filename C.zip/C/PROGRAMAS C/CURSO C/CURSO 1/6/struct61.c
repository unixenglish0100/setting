#include<stdio.h>
#include<string.h>
#define N 50
typedef struct{
char nombre[N];
int paginas;
float precio;

}libro;
libro JT,MAT;

int main(){
system("clear");

strcpy(JT.nombre,"juego de trono");
JT.paginas=300;
JT.precio=25.34;

strcpy(MAT.nombre,"matrix");
MAT.paginas=600;
MAT.precio=304.32;

printf("\n\nel nombre del primer libro es %s",JT.nombre);
printf("\nlas paginas que tiene el libro son %i",JT.paginas);
printf("\nel precio del libro es %f\n\n",JT.precio),JT.precio;

printf("\n\nel nombre del primer libro es %s",MAT.nombre);
printf("\nlas paginas que tiene el libro son %i",MAT.paginas);
printf("\nel precio del libro es %f\n\n",MAT.precio);

return 0;
}

