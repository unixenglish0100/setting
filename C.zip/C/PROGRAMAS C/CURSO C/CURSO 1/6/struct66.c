#include<stdio.h>
typedef struct{
int matematicas;
int ingles;
int fisica;
}materias;

void darnota(materias *not);

int main(){
system("clear");
materias not;

darnota(&not);

//printf("\nla nota de matematicas es %i\n",not.matematicas);
//printf("\nla nota de ingles es %i\n",not.ingles);
//printf("\nla nota de fisica es %i\n",not.fisica);


return 0;
}

void darnota(materias *not){
                            printf("\ncual es la nota de matematicas:    ");
			    scanf("%i",&not->matematicas);
                            printf("\ncual es la nota de ingles:    ");
			    scanf("%i",&not->ingles);
                            printf("\ncual es la nota de fisica:    ");
          		    scanf("%i",&not->fisica);  		                            
                        
			    printf("\nla nota de matematicas es %i\n",(*not).matematicas);
                            printf("\nla nota de ingles es %i\n",not->ingles);
                            printf("\nla nota de fisica es %i\n",not->fisica);
                          }
