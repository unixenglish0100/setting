//programa sobre un traductor de ingles a español
#include<stdio.h>
#define N 50
void vacio();
void anadir();
void traducir();
void tradu(int op);

typedef struct{

char eng[N];
char esp[N];
int lleno;

}traductor;

traductor trad[N];

int main(){
system("clear");

int op;
char key;
key='s';

do{
   do{
       printf("********************************");
       printf("\n          MENU");
       printf("\n++++++++++++++++++++++++++++");
       printf(" \n1. ingresar dato");
       printf("\n2. traducir\n\n:");
       scanf("%i",&op);
      }while(op<1 || op>2);

      switch(op){
                 case 1: anadir(); break;
                 case 2: traducir(); break; 
                }
      printf("\n\nretornar programa(s/n):   ",getchar());
      key=getchar();
      system("clear");
   }while(key=='s' || key=='S');

return 0;
}

void vacio(){
              int i;
              for(i=0;i<N;i++){
                                trad[i].lleno=0;
                              }
            }

void anadir(){
               int i,aux;
               aux=0;
               for(i=0;i<N && aux==0;i++){
                                           if(trad[i].lleno==0){
                                                                 printf("\ndigite palabra en ingles:  ");
                                                                 scanf("%s",&trad[i].eng);
                                                                 printf("\ndigite palabra en español:  ");
                                                                 scanf("%s",&trad[i].esp);
                                                                 printf("\n\n%s\n%s\n\n",trad[i].eng,trad[i].esp);
                                                                 trad[i].lleno=1;
                                                                 aux=1;
                                                               }
                                         }
             }

void traducir(){
                 int op;
                 do{
                     printf("********************************");
                     printf("\n          MENU");
                     printf("\n++++++++++++++++++++++++++++");
                     printf(" \n1. traducir de ingles a español");
                     printf("\n2. traducir de español a ingles\n\n:");
                     scanf("%i",&op);
                   }while(op<1 || op>2);

                  switch(op){
                              case 1: tradu(op); break;
                              case 2: tradu(op); break;
                            }
                }

void tradu(int op){
                    int i,j,temp;
                    char aux[N];
                    temp=0;
                    printf("\nintroduce la palabra que desea buscar:   ");
                    scanf("%s",&aux);
                    if(op==1){
                               for(i=0;i<N && temp==0;i++){
                                                            j=strcmp(aux,trad[i].eng);
                                                            if(j==0){
                                                                      printf("\n\nla traducion de la palabra %s en español es %s\n\n",trad[i].eng,trad[i].esp); 
                                                                      temp=1;
                                                                    }
                                                          }
                             }

                    else{
                           for(i=0;i<N && temp==0;i++){
                                                         j=strcmp(aux,trad[i].esp);
                                                         if(j==0){
                                                                   printf("\n\nla traducion de la palabra %s en ingles es %s\n\n",trad[i].esp,trad[i].eng);
                                                                   temp=1;
                                                                  }
                                                       }
                        }
                  }




















