#include<stdio.h>
#include<stdlib.h>

void aleatorio(int a[100],int tam);
int main(){
system("clear");
int N=3;
int v[100];
int *con;
int i,op;

con=(int*) calloc(N,sizeof(int));
if(con==NULL){
	       printf("\nlo siento no hay espasio\n");
             }
else{
      aleatorio(v,100);
      for(i=0;i<100;i++){
	                  op=v[i];
	                  *(con+op)+=1;
                        }
      for(i=0;i<N;i++){
	                printf("%i, ",*(con+i));
                      }
      printf("\n\n");
    }

free(con);

return 0;
}

void aleatorio(int a[100],int tam){
	                            int i;
				    srand(time(NULL));
				    for(i=0;i<tam;i++){
				    	                a[i]=rand()%3;
						        printf("%i, ",a[i]);
				                      }
				    printf("\n\n");
                                  }
