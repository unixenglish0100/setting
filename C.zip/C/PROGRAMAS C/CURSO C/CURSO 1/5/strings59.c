//programa que cambia '\n' a '\0'
#include<stdio.h>
void cambio(char c[10]);
int main(){
system("clear");

char v[10];

printf("digite cadena de caracter:     ");
fgets(v,10,stdin);

//cambio(v);

printf("%s\n",v);

return 0;
}

void cambio(char c[10]){
                         int i;
                         for(i=0;i<10;i++){
                                            if(c[i]=='\n'){
                                                            c[i]='\0';
                                                          }
                                          }
                       }
