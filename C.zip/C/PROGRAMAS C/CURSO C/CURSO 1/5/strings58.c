//programa sobre strings con funciones string
#include<stdio.h>
#include<string.h>
int main(){
system("clear");
char v[13];
char v1[13];

printf("\ndigite primera cadena de caracteres:  ");
fgets(v,13,stdin);

printf("\ndigite segunda cadena:    ");
fgets(v1,13,stdin);

if(strcmp(v,v1)==0){
                     printf("\n\nlas dos cadenas son iguales\n\n");
                   }
else{
      printf("\n\nlas dos cadenas son diferentes\n\n");
    }


return 0;
}
