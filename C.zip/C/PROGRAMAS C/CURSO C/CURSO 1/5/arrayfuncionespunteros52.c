//programa sobre funciones de arrays o vectores con punteros que hace un dado probabilidades 10000
#include<stdio.h>
void sorteo(int *v);
void leer(int *v);
int main(){
system("clear");

int v[]={0,0,0,0,0,0};
sorteo(v);
leer(v);
return 0;
}
void sorteo(int *v){
                     srand (time(NULL)); 
                     int i,aux;
                     for(i=0;i<10000;i++){
                                           aux=rand()%6;

                                           switch(aux){
                                                        case 0: {
                                                                  *(v+aux)+=1;
                                                                  break;
                                                                }
                                                        case 1: {
                                                                  *(v+aux)+=1;
                                                                  break;
                                                                }
                                                        case 2: {
                                                                  *(v+aux)+=1;
                                                                  break;
                                                                }
                                                        case 3: {
                                                                  *(v+aux)+=1;
                                                                  break;
                                                                }
                                                        case 4: {
                                                                  *(v+aux)+=1;
                                                                  break;
                                                                }
                                                        case 5: {
                                                                  *(v+aux)+=1;
                                                                  break;
                                                                }

                                                      }
                                         }
 
                   }
void leer(int *v){
                   int i;
                   float x;
                   for(i=0;i<6;i++){
                                      x=(*(v+i)*100)/10000.;
                                      printf("\nla probabilidad de que el numero %i salga es de %f\n",i+1,x);
                                   }
                 }


