//programa de strigs que cambia las 'a' por ' '
#include<stdio.h>
#include<string.h>
void cambio(char c[]);
int main(){
system("clear");

char v[]="si os esta gustando este video os podeis suscribir al canal";

cambio(v);

printf("%s\n",v);

return 0;
}

void cambio(char c[]){
                       int i,l;
                       l=strlen(c);
                       for(i=0;i<l;i++){
                                        if(c[i]=='a'){
                                                      c[i]=' '; 
                                                     } 
                                       }
                     }
