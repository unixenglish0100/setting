#include<stdio.h>
void digitar(int d[2][2]);
void listar(int l[2][2]);
void comparar(int c[2][2],int c1[2][2]);
int main(){
system("clear");
int v[2][2];
int v1[2][2];

digitar(v);
digitar(v1);
listar(v);
listar(v1);
comparar(v,v1);

return 0;
}

void digitar(int d[2][2]){
                           int i,j;
                           for(i=0;i<2;i++){
                                            for(j=0;j<2;j++){
                                                              printf("\ndigite valor[%i][%i]:  ",i,j);
                                                              scanf("%i",&d[i][j]);
                                                            } 
                                           }
                         }

void listar(int l[2][2]){
                          int i,j;
                          for(i=0;i<2;i++){
                                           for(j=0;j<2;j++){
                                                             printf("%i  ",l[i][j]);
                                                           }
                                           printf("\n");
                                          } 
                          printf("\n\n"); 
                        }

void comparar(int c[2][2],int c1[2][2]){
                                         int i,j,k;
                                         for(i=0;i<2 && k==0;i++){
                                                                   for(j=0;j<2 && k==0;j++){
                                                                                             if(c[i][j]!=c1[i][j]){
                                                                                                                     k=1;
                                                                                                                   }
                                                                                           }
                                                                 }
                                         if(k==0){
                                                   printf("\nlas dos matrices son inguales\n\n");
                                                 }
                                         else{
                                                printf("\nlas dos matrices no son iguales\n\n");
                                              }
                                        }
