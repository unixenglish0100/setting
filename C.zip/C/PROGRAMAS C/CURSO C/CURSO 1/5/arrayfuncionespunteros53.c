//programa sobre funciones de arrays o vectores con punteros que hace un dado probabilidades 10000
#include<stdio.h>
void sorteo(int *s);
void leer(int *l);
int main(){
system("clear");

int v[]={0,0,0,0,0,0};
sorteo(v);
leer(v);
return 0;
}
void sorteo(int *s){
                     srand(time(NULL)); 
                     int i,aux;
                     for(i=0;i<10;i++){
                                           aux=rand()%6;

                                           switch(aux){
                                                        case 0: *(s+aux)+=1; break;
                                                        case 1: *(s+aux)+=1; break;
                                                        case 2: *(s+aux)+=1; break;
                                                        case 3: *(s+aux)+=1; break;
                                                        case 4: *(s+aux)+=1; break;
                                                        case 5: *(s+aux)+=1; break;

                                                       }
                                         }
 
                   }
void leer(int *l){
                   int i;
                   float x;
                   for(i=0;i<6;i++){
                                      x=(*(l+i)*100)/10.;
                                      printf("\nla probabilidad de que el numero %i salga es de %f      %i\n",i+1,x,*(l+i));
                                   }
                 }


