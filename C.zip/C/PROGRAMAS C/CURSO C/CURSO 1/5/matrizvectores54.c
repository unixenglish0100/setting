//programa sobre matriz con vectores o arrays
#include<stdio.h>
void digitar(int d[5][5]);
void listar(int l[5][5]);
int main(){
system("clear");
int m[5][5];

digitar(m);
listar(m);

return 0;
}

void digitar(int d[5][5]){
                           int i,j;
                           srand(time(NULL));
                           for(i=0;i<5;i++){
                                             for(j=0;j<5;j++){
                                                               d[i][j]=rand()%10;
                                                             }
                                           }
                         }

void listar(int l[5][5]){
                          int i,j;
                          for(i=0;i<5;i++){
                                           for(j=0;j<5;j++){
                                                             printf("%i  ",l[i][j]);
                                                           }
                                           printf("\n");
                                          }
                          printf("\n\n");
                        }
