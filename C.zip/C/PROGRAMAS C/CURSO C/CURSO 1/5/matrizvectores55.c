//programa de matices o vectores con funciones que compara dos matrices
#include<stdio.h>
void digitar(int d[2][2]);
void comparar(int c[2][2],int c1[2][2]);

int main(){
system("clear");
int m[2][2];
int m1[2][2];

digitar(m);
digitar(m1);
comparar(m,m1);


return 0;
}

void digitar(int d[2][2]){
                           int i,j;
                           for(i=0;i<2;i++){
                                             for(j=0;j<2;j++){
                                                               printf("\ndigite m[%i][%i]:  ",i+1,j+1);
                                                               scanf("%i",&d[i][j]);
                                                             }
                                           }
                         }

void comparar(int c[2][2],int c1[2][2]){	
                                         int i,j,aux;
                                         for(i=0;i<2 && aux==0;i++){
                                                                     for(j=0;j<2 && aux==0;j++){
                                                                                                  if(c[i][j]!=c1[i][j]){
                                                                                                                        aux=1;
                                                                                                                       }
                                                                                               }
                                                                    }
                                         if(aux==0){
                                                     printf("\n\nambas matrices son inguales\n\n");
                                                   }
                                         else{
                                               printf("\n\nlas dos matrices no son iguales\n\n");
                                             }
                                       }

