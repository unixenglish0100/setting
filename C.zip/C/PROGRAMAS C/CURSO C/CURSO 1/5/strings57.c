//programa sobre cadenas de caracteres strings
#include<stdio.h>
int main(){
system("clear");

char v[13];

printf("\ndigite frase:    ");
fgets(v,13,stdin);

printf("\n\n%s\n\n",v);

return 0;
}

