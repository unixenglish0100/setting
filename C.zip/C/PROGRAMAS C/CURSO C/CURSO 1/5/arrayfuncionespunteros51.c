//programa que lista 3 numeros en arrays o vectores en funciones
#include<stdio.h>
void digitar(int *d);
void listar(int *l);
int main(){
system("clear");
int v[5];

digitar(v);
listar(v);

return 0;
}

void digitar(int *d){
                      int i;
                      for(i=0;i<4;i++){
                                       printf("\ndigite posicion %i:    ",i+1);
                                       scanf("%i",(d+i));
                                      }
                    }

void listar(int *l){
                     int i;
                     for(i=0;i<4;i++){
                                       printf("%i, ",*(l+i));
                                     }
                     printf("\n\n");
                   }

