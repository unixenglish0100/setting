#include<stdio.h>
#include<stdlib.h>
#include<string.h>

typedef struct{
char *nombre;
char *autor;
}libro;
void cambio(char aux[100]);

int main(){
system("clear");
char aux[50];

libro JDT;
printf("\nintroduce nombre:   ");
fgets(aux,50,stdin);
cambio(aux);

//JDT.nombre=(char*) realloc(JDT.nombre,(strlen(aux)+1)*sizeof(char));
JDT.nombre=(char*) malloc((strlen(aux)+1)*sizeof(char));  //asignado espasio en memoria
if(JDT.nombre==NULL){
	              printf("\nlo siento no hay espasio en memoria\n");
		      exit(1);
                    }
strcpy(JDT.nombre,aux);
printf("\n%s\n\n",JDT.nombre);


printf("\nintroduce autor:   ");
fgets(aux,50,stdin);
//while(getchar()!='\n');
cambio(aux);

JDT.autor=(char*) malloc((strlen(aux)+1)*sizeof(char));
if(JDT.autor==NULL){
	              printf("\nlo siento no hay espasio en memoria\n");
		      exit(1);
                    }
strcpy(JDT.autor,aux);
printf("\n%s\n\n",JDT.autor);

free(JDT.nombre);
free(JDT.autor);

return 0;
}

void cambio(char aux[50]){
	                   int i,temp=0;
			   for(i=0;i<100 && temp==0;i++){
				                          if(aux[i]=='\n'){
						                            aux[i]=='\0';
								            temp=1;
					                                  }
			                                }   
                         }


