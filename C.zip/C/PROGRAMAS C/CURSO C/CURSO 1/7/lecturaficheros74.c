#include<stdio.h>
int main(){
system("clear");
char aux;
char aux2[50];
FILE *f;

f=fopen("repaso.txt","r");
if(f==NULL){
	     printf("\nno se a podido abrir el fichero\n");
	     exit(1);
           }

while(aux!=EOF){
	         aux=fgetc(f);
		 printf("%c",aux);
               }
printf("\n");

fclose(f);

f=fopen("repaso2.txt","r");
if(f==NULL){
	     printf("\nno se a podido abrir el fichero\n");
	     exit(1);
           }

while(!feof(f)){
	         fgets(aux2,50,f);
		 printf("%s",aux2);
               }
printf("\n");

fclose(f);

return 0;	
}
