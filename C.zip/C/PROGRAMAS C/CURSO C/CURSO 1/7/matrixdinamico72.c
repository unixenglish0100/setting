#include<stdio.h>
#include<stdlib.h>
int main(){
system("clear");
int i,j;
int columnas,filas;
int **m1;
int **m2;

printf("\ndigite el numero de filas:   ");
scanf("%i",&filas);

printf("\ndigite el numero de columnas:   ");
scanf("%i",&columnas);

m1=(int**) malloc(filas*sizeof(int*));
if(m1==NULL){
	      printf("\nno se a asignado espasio en memoria\n");
	      exit(1);
            }
for(i=0;i<filas;i++){
	              m1[i]=(int*) malloc(columnas*sizeof(int));
		      if(m1[i]==NULL){
		    	               printf("\nno se a asignado espasio en memoria\n");
				       exit(1);
		                     }
		      
                    }

for(i=0;i<filas;i++){
	              for(j=0;j<columnas;j++){
			                       scanf("%i",&m1[i][j]);
		                             }
                    }

m2=(int**) malloc(filas*sizeof(int*));
if(m2==NULL){
	      printf("\nno se a asignado espasio en memoria\n");
	      exit(1);
            }
for(i=0;i<filas;i++){
	              m2[i]=(int*) malloc(columnas*sizeof(int));
		      if(m2[i]==NULL){
			               printf("\nno se a asignado espasio en memoria\n");
				       exit(1);
		                     }
		    }
for(i=0;i<filas;i++){
	              for(j=0;j<columnas;j++){
			                       m2[i][j]=m1[i][j];
					       printf("%i ",m2[i][j]);
		                             }
		      printf("\n");
                    }

return 0;
}



