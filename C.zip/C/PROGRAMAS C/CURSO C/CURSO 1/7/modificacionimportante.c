#include<stdio.h>
#include<string.h>
#define N 50
typedef struct{
char eng[N];
char esp[N];
int lleno;
}traductor;

traductor trad[N];

void vacio();
void cambio(char palabra[N]);
void ingresar();
void traducir();
void traduciendo(int op);
int main(){
system("clear");
int op;
char key;
key='s';

do{
   do{
      printf("1. ingresar dato");
      printf("\n2. traducir\n:"); 
      scanf("%i",&op);     
     }while(op<1 || op>2);
   
   switch(op){
	       case 1: ingresar(); break;
	       case 2: traducir(); break;
             }

   printf("\nretornar programa(s/n):   ",getchar());
   key=getchar();
   system("clear");   
  }while(key=='s' || key=='S');

return 0;
}

void vacio(){
	       int i;
	       for(i=0;i<N;i++){
		                 trad[i].lleno=0;
	                       }
             }

void cambio(char palabra[N]){
	                      int i;
			      for(i=0;i<N;i++){
				                if(palabra[i]=='\n'){
							              palabra[i]='\0';
						                    }
			                      }
                            }

void ingresar(){
	         int i;
		 int re=0;
		 for(i=0;i<N && re==0;i++){
			                     if(trad[i].lleno==0){
					                           while(getchar()!='\n');
					                           printf("\ndigite letra en ingles:   ");
						                   fgets(trad[i].eng,N,stdin);
								   cambio(trad[i].eng);
							           printf("\ndigite letra en español:  ");
							           fgets(trad[i].esp,N,stdin);
								   cambio(trad[i].esp);
							           trad[i].lleno=1;
							           re=1;
				                                  }
		                          }
               }

void traducir(){
	         int op;
                 do{
                     printf("1. traducir de ingles a español");
                     printf("\n2. traducir de español a ingles\n:"); 
                     scanf("%i",&op);     
                   }while(op<1 || op>2);
   
                 switch(op){
	                     case 1: traduciendo(op); break;
	                     case 2: traduciendo(op); break;
                           }
               }

void traduciendo(int op){
	                  int i;
                          char aux[N];
		          if(op==1){
				     while(getchar()!='\n');
				     printf("\ndigite palabra en ingles:   ");
				     fgets(aux,N,stdin);
				     cambio(aux);
				     for(i=0;i<N;i++){
				                       if(strcmp(aux,trad[i].eng)==0){
							                               printf("\nla palabra %s en español es %s\n",trad[i].eng,trad[i].esp);
						                                     }	               
				                     }
			           }
		          else{ 
				while(getchar()!='\n');
				printf("\ndigite palabra en español:   ");
				fgets(aux,N,stdin);
				cambio(aux);
				for(i=0;i<N;i++){
				                  if(strcmp(aux,trad[i].esp)==0){
				    	                                          printf("\nla palabra %s en ingles es %s\n",trad[i].esp,trad[i].eng);
						                                }	               
				                }
			      }	  
                        }








