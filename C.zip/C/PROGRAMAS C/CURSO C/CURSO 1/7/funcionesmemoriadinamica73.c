#include<stdio.h>
#include<stdlib.h>

int reservarmem(int fi,int cn);
void introducir(int fi,int cn,int **mat);
void mostrar(int fi,int cn,int **mat);
void comparar(int fi,int cn,int **m1,int **m2);
int main(){
system("clear");	
int **m1;
int **m2;
int fi,cn;
int i,j;

printf("\ndigite numero de filas:   ");
scanf("%i",&fi);
printf("\ndigite numero de columnas:  ");
scanf("%i",&cn);

m1=reservarmem(fi,cn);
m2=reservarmem(fi,cn);

introducir(fi,cn,m1);
introducir(fi,cn,m2);

mostrar(fi,cn,m1);
printf("\n\n");
mostrar(fi,cn,m2);

comparar(fi,cn,m1,m2);

free(m1);
free(m2);
return 0;
}

int reservarmem(int fi,int cn){
	                         int **mat;
				 int i;
				 mat=(int**) malloc(fi*sizeof(int*));
				 if(mat==NULL){
					        printf("\nno se a asignado espasio en memoria\n");
						exit(1);
				              }
				 for(i=0;i<fi;i++){
					            mat[i]=(int*) malloc(cn*sizeof(int));
				                    if(mat[i]==NULL){
					                              printf("\nno se a asignado espasio en memoria\n");
						                      exit(1);
				                                    }					            	    
				                  }
				 return mat;
                               }

void introducir(int fi,int cn,int **mat){
	                                 int i,j;
	                                 for(i=0;i<fi;i++){
						            for(j=0;j<cn;j++){
								               printf("\ndigite numero[%i][%i]:  ",i,j);
									       scanf("%i",&mat[i][j]);
							                     }
					                  }
                                       }

void mostrar(int fi,int cn,int **mat){
	                               int i,j;
				       for(i=0;i<fi;i++){
				    	                  for(j=0;j<cn;j++){
								             printf("%i ",mat[i][j]); 
							                   }
							  printf("\n");
				                        }
                                     }

void comparar(int fi,int cn,int **m1,int **m2){
	                                        int i,j,k=0;
						for(i=0;i<fi && k==0;i++){
							                    for(j=0;j<cn && k==0;j++){
									                               if(m1[i][j]!=m2[i][j]){
											                                       k=1;
										                                             }
								                                     }
						                         }
                                                if(k==0){
							   printf("\nlas dos matrices son iguales\n\n");
						        }
						else{
						      printf("\nlas dos matrices son distintas\n\n");
						    }
                                              }










