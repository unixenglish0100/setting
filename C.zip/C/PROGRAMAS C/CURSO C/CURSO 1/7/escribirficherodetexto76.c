#include<stdio.h>
void cambio(char c[50]);
int main(){
system("clear");
FILE *f;
int n,n1;
char aux[50];
f=fopen("fichero1.txt","w");
if(f==NULL){
	     printf("\nno se a podido abrir el fichero\n");
	     exit(1);
           }
printf("\nintroduce un numero por teclado:   ");
scanf("%i",&n);
fprintf(f,"\nel numero introducido por teclado es %i\n",n);

printf("\nintroduce un numero por teclado:   ");
scanf("%i",&n1);
fprintf(f,"\nel numero introducido por teclado es %i\n",n1);

while(getchar()!='\n');
printf("\ndigite frase:   ");
fgets(aux,50,stdin);
cambio(aux);

fprintf(f,"la frase es %s",aux);



fclose(f);

return 0;
}

void cambio(char c[50]){
	                 int i;
			 for(i=0;i<50;i++){
	                                    if(c[i]=='\n'){
				                            c[i]='\0';
			                                  }
			                  }   
                       }
