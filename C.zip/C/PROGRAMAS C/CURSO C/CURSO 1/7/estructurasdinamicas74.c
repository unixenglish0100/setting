#include<stdio.h>
#include<stdlib.h>
#include<time.h>

typedef struct{ 
int salud;
int mana;
int fuerza;
int magia;
}heroe;

typedef struct{
int salud;
int fuerza;
}malo;

heroe yo;
malo *otros;

void introduceyo();
void introducemalo(int N);
void asignamem(int *N);

int main(){
system("clear");
int op,i,objetivo,pegar;
int cont=0;
int N=0;
srand(time(NULL));
introduceyo();

asignamem(&N);

do{
   do{
       printf("\n\n(1) atacar");
       printf("\n(2) magia\n  :"); 
       scanf("%i",&op);      
     }while(op<1 || op>2);

   printf("\nelige al malo al que quieres pegar:   ");
   for(i=0;i<N;i++){
	             printf("\nmalo %i tiene una vida de %i\n",i,otros[i].salud);
                   }
   scanf("%i",&objetivo);

   if(otros[objetivo].salud>0){
                                switch(op){
	                                    case 1: pegar=yo.fuerza; printf("\nhe pegado %i",pegar); 
						    otros[objetivo].salud -= pegar; 
						    printf("\nla salud del malo %i es de %i",objetivo,otros[objetivo].salud);
						    break;
	                                    case 2: if(yo.mana>0){
							           pegar=yo.magia*(rand()%3);
								   printf("\nhe pegado %i",pegar);
						                   otros[objetivo].salud -= pegar; 
						                   printf("\nla salud del malo %i es de %i\n",objetivo,otros[objetivo].salud);
						                 }
				                    else{
							  printf("\nno tienes mana\n");   
						        }	
					            break;	    
                                          }   
	                        
                              }
   else{
	 printf("\ndeja a los cadaveres\n");
       }

printf("\n\nturno de los malos");
for(i=0;i<N;i++){
	          if(otros[i].salud>0){
	                                 pegar=otros[i].fuerza * (rand()%3);
                                         printf("\nel malo %i me ha pegado %i",i,pegar);
		                         yo.salud-=pegar;
                                         printf("\nmi salud es de %i",yo.salud);
				       }	 
                }

if((cont%2==0)){
	        otros=(malo*) realloc(otros,(N+1)*sizeof(malo));
		if(otros==NULL){
			        printf("\nno se a asignado espasio en memoria\n");
				exit(1);
		               }
		introducemalo(N);
		N++;
               }
cont++;

  }while(yo.salud>0);

return 0;
}

void introduceyo(){
	            yo.salud=1000;
		    yo.mana=100;
		    yo.fuerza=50;
		    yo.magia=100;
                  }

void introducemalo(int N){
	                   otros[N].salud=100;
			   otros[N].fuerza=50;
                         }

void asignamem(int *N){
   	                otros=(malo*) malloc((*N+1)*sizeof(malo));
		        if(otros==NULL){
			                 printf("\nno se a asignado espasio en memoria\n");
			     	         exit(1);
		                       }
		        introducemalo(*N);
		        (*N)++;
                      }












