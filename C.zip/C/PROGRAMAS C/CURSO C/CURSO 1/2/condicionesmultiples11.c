// programa sobre condiciones multiples

# include <stdio.h>
int main (){

int x;
system("clear");

printf("\n\nDigite numero entre 1 y 10:    ");
scanf("%i",&x);

if(x>=1 && x<=10){ // && significa que las 2 condiciones se tienen que cumplir
                   printf("\n\nel numero %i esta entre los numeros del 1 al 10\n\n",x);
                 }
else{
      printf("\n\nel numero %i no esta entre los numeros del 1 al 10\n\n",x);
    }

return 0;

}
