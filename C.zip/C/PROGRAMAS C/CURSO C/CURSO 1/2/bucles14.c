// estructuras iterativas
# include <stdio.h>
int main()  {

int x,y,i;
system("clear");

printf("\n\ndigite primer numero:    ");
scanf("%i",&x);
printf("\ndigite segundo numero mayor que el anterior:   ");
scanf("%i",&y);

// bucle for

for(i=x+1;i<=y;i++ ){
                      printf("%i, ",i);
                    }

printf("\n\n");

// bucle while

i= x+1;
while(i<=y){
             printf("%i, ",i);
             i++;
           }
printf("\n");



return 0;


}
