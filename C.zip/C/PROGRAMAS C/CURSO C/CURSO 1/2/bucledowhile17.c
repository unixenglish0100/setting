// programa sirve que nos pregunte si queremos continuar o no
# include <stdio.h>
int main()  {

/*int i;
  i=10;*/
system("clear");

/* while(i<15){
             printf("\n\nesto no se va ejecutar nunca\n\n");
             i++;
           }
*/
 /* do{
    printf("\n\nesto al menos se ejecutara al menos una vez\n\n");
    i++;

    }while(i<15); */ 

char c;

do{

   printf("\nintroduce una letra:  ");
   scanf("%c",&c);
   while(getchar()!='\n'); 
  
}while(c != 's' && c != 'S');
  
return 0;

}
