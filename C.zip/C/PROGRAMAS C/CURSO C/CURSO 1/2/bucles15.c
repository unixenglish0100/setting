// programa que suma todos los pares de 2 hasta 1000
# include <stdio.h>
int main (){

int i;
float sum;
sum=0;
system("clear");

// bucle for

for(i=2;i<=2000;i=i+2){
                        sum += i;
                      }

printf("\nla suma de dos en dos hasta 2000 es %f\n\n",sum);


// bucle while

i=2;
sum=0;
while(i<=2000){
                sum += i;
                i = i + 2;
              }
printf("\n\nla suma de dos en dos hasta 2000 es %f\n\n",sum);

return 0;
}
