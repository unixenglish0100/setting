// programa que lista los numeros comprendidos entre el menor y el mayor
# include <stdio.h>
int main (){

int x,y,i;
system("clear");

printf("\n\ndigite primer numero:   ");
scanf("%i",&x);

do{
    printf("\n\ndigite segundo numero mayor al anterior:    ");
    scanf("%i",&y);

}while(x>=y);

for(i=x+1;i<=y;i++){
                     printf("%i, ",i);
                   }

printf("\n");

return 0;


}
