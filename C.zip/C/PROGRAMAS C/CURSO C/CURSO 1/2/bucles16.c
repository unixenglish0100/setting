// programa sobre cuantos numeros hay que meter y sacarle su media

# include <stdio.h>
int main(){

int x,y,i;
float sum,div;
system("clear");

printf("\n\nDigite cuantos numeros quiere sacar para su media:    ");
scanf("%i",&x);

sum=0;
i=1;
while(i<=x){
             printf("\ndigite %i. numero:   ",i);
             scanf("%i",&y);
             sum=sum+y;
             i++;
           }

div=sum/x;
printf("\n\nla media de los %i numeros es %f\n\n",x,div);

return 0;

}


