// programa que simula un cronometro
# include <stdio.h>
# include <unistd.h>
int main(){

system("clear");

int hor,min,seg,x;
x=1000;

for(hor=0;hor<24;hor++){
                        for(min=0;min<60;min++){
                                                 for(seg=0;seg<60;seg++){
                                                                          printf("%02i:%02i:%02i\n",hor,min,seg);
                                                                          // usleep(1000 * x);
                                                                          sleep(1);
                                                                        }
                                                }
                       }


return 0;

}
