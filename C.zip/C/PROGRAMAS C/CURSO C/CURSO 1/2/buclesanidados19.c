// programa sobre las tablas de multiplicar
# include <stdio.h>
int main(){

int i,j;
system("clear");

for(i=1;i<=9;i++){
                   for(j=1;j<=10;j++){
                                       printf("\n%i * %i = %i",i,j,i*j);
                                     }
                   printf("\n");
                   while(getchar()!='\n');
                 }

return 0;


}
