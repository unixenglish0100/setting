// programa que me dice la hora adelantada en 1 segundo

# include <stdio.h>
int main (){

int hor,min,seg;
system("clear");

printf("\n\ndigite hora:   ");
scanf("%i",&hor);
printf("\ndigite minutos:   ");
scanf("%i",&min);
printf("\ndigite segundos:   ");
scanf("%i",&seg);

if(hor<=23 && min<=59 && seg<=59){
                                   seg += 1;

                                   if(seg==60){
                                                min += 1;
                                                seg = 00;
                                              }
                                   if(min==60){
                                                hor += 1;
                                                min = 00;
                                              }
                                   if(hor==24){
                                                hor=00;
                                              }


                                   printf("\n\nLa hora es %i:%i:%i\n\n",hor,min,seg);
                                 }
else{
      printf("\n\nla hora no es valida\n\n");
    }

return 0;


}

