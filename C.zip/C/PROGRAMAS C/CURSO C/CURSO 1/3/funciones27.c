// programa sobre funciones
# include <stdio.h>
int numeros();
int main(){

system("clear");
int x,y;

x=3;
y=10;

numero(x,y);

return 0;
}

int numero(int a,int b){
                        printf("\n\na es %i y b es %i\n\n",a,b);
                       }

