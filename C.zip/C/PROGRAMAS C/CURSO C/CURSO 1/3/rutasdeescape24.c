// programa que dice si un numero es primo o no utilizando rutas de escape
# include <stdio.h>
int main(){

int n,i,j,aux;

system("clear");

printf("\n\ndigite numero:    ");
scanf("%i",&n);

j=0;
 
for(i=2;i<n && j!=1;i++){
                          aux=n%i;
                          if(aux==0){
                                      j=1;
                                    }
               }
if(j==1){
         printf("\n\nel numero %i no es primo\n\n",n);
        }
else{
      printf("\n\nel numero %i es primo\n\n",n);
    }

return 0;

}
