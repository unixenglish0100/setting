//programa que saca el factorial de dos numeros
# include <stdio.h>
int factorial(int a);
int main(){

int x,y,fac1,fac2;
system("clear");

printf("\n\ndigite primer numero pa sacar factorial:   ");
scanf("%i",&x);

printf("\n\ndigite segundo numero pa sacar factorial:   ");
scanf("%i",&y);

fac1=factorial(x);
fac2=factorial(y);

printf("\n\nel factorial de %i es %i\n\n",x,fac1);
printf("el factorial de %i es %i\n\n",y,fac2);



return 0;
}

int factorial(int a){
                      
                      int i, aux;
                      aux=1;
                      for(i=1;i<=a;i++){
                                         aux*=i;
                                       }
                      return aux;
                     }

