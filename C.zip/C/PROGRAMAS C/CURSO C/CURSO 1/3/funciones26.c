e/ programa sobre funciones
# include <stdio.h>
int maximo();
int main(){

system("clear");
maximo();

printf("\n\nestamos dentro de main\n\n");

return 0;
}

int maximo(){
              printf("\n\nestamos dentro de maximo");
              return 0;
            }          

