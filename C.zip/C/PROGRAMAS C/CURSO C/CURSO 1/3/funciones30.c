// programa sobre funciones que dice si dos numeros son impares
# include <stdio.h>

int primo(int a);
int main(){

int x,y,prim1,prim2;
system("clear");

printf("\n\ndigite numero pa listar si es primo:   ");
scanf("%i",&x);

printf("\ndigite segundo numero pa listar si es primo:   ");
scanf("%i",&y);

prim1=primo(x);
prim2=primo(y);

if(prim1==0){
              printf("\n\nel numero %i es primo\n\n",x);
            }
else{
      printf("\n\nel numero %i no es primo\n\n",x);
    }

if(prim2==0){
              printf("\n\nel numero %i es primo\n\n",y);
            }
else{
      printf("\n\nel numero %i no es primo\n\n",y);
    }


return 0;

}

int primo(int a){
                   int i,k,aux;
                   k=0;
                   for(i=2;i<a && k!=1;i++){
                                             aux=a%i;
                                             if(aux==0){
                                                         k=1;
                                                       }
                                           }
                   return k;
                }

                
