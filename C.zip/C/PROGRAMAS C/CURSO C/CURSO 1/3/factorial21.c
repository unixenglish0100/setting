// programa que calcula su factorial
# include <stdio.h>
int main(){

int x,i,fac;
system("clear");

fac=1;

printf("\n\ndigite un numero para calcular su factorial:    ");
scanf("%i",&x);

/*

// bucle for
for(i=1;i<=x;i++){
                   fac=fac*i;
                 }
printf("\n\nel factorial de %i es %i\n\n",x,fac);
*/

// bucle while

i=1;
while(i<=x){
             fac=fac*i;
             i++;
           }
printf("\n\nel factorial de %i es %i\n\n",x,fac);


return 0;

}

