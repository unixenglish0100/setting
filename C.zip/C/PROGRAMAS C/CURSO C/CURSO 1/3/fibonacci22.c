// programa que saca la serie fibonacci

# include <stdio.h>
int main(){

int x,y,n,res,i;

system("clear");

printf("\n\ndigite numero pa calcular en la serie fibonacci:   ");
scanf("%i",&n);

if(n==1){
          printf("0");
        }
else{
      printf("0, 1, ");
    }

x=0;
y=1;
// i=3;

// bucle while
/*
while(i<=n){
             res=x+y;
             printf("%i, ",res);
             x=y;
             y=res;
             i++;
            }
printf("\n\n"); */
// bucle for
for(i=3;i<=n;i++){
                   res=x+y;
                   printf("%i, ",res);
                   x=y;
                   y=res;
                 } 
printf("\n\n");
   
return 0;

}
