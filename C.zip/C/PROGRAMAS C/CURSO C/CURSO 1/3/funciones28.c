// programa que muestra en pantalla el numero mayor de 2 numeros
# include <stdio.h>
int mayor();

int main(){

int x,y,max;
system("clear");

x=3;
y=20;

max=mayor(x,y);

printf("\n\nel mayor de dos numeros es %i\n\n",max);


return 0;
}

int mayor(int a,int b){
                        int aux;
                        if(a>b){
                                 aux=a;
                               }
                        else{
                              aux=b;
                            }
                        return aux;
                      }

