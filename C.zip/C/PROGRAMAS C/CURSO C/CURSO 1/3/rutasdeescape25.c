// programa que lista los numeros primos del 2 al 2000
# include <stdio.h>
int main(){

int i,j,k,aux;
system("clear");


for(i=2;i<2000;i++){
                     k=0;
                     for(j=2;j<i && k!=1;j++){
                                               aux=i%j;
                                               if(aux==0){
                                                           k=1;
                                                         }
                                              }
                      if(k!=1){
                                printf("%i, ",i);
                              }
                    }

return 0;

}
