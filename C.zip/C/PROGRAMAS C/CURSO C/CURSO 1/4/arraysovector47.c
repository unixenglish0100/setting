//programa que pide 10 numeros y luego los lista con vectores o arrays
#include<stdio.h>
int main(){
system("clear");

int v[10],i;

for(i=0;i<10;i++){
                   printf("\ndigite la posicion %i:    ",i);
                   scanf("%i",&v[i]);
                 }

printf("\n\n");
for(i=0;i<10;i++){
                   printf("%i, ",v[i]);
                 }
printf("\n\n");

return 0;
}
