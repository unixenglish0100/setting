// programa sobre punteros y lo que hace es cambiar de valor de una variable a otra
# include <stdio.h>
void cambio(int *a,int *b,int *c,int d);
int main(){

int x,y,z,n;
system("clear");
x=5;
y=20;
z=400;
n=500;

cambio(&x,&y,&z,n);

printf("\n\nx = %i   y = %i    z = %i   n = %i\n\n",x,y,z,n);

return 0;
}

void cambio(int *a,int *b,int *c,int d){
                                         int aux;
                                         aux=*a;
                                         *a=*b;
                                         *b=aux;
                              
                                         *c=1000;
                                         d=2000;
                                        }




