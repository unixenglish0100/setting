//programa sobre vectores o arrays sobre punteros
#include<stdio.h>
int main(){
system("clear");
int v[3]={1,2,3};
int i;

for(i=0;i<3;i++){
                  printf("%i, ",*(v+i));
                }


return 0;
}
