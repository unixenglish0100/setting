//programa de vectores con funciones
#include<stdio.h>
void digitar(int d[]);
void listar(int l[]);
int main(){
system("clear");
int v[2];

digitar(v);
listar(v);

return 0;
}

void digitar(int d[]){
                       int i;
                       for(i=0;i<2;i++){
                                         printf("\ndigite la posicion %i:  ",i);
                                         scanf("%i",&d[i]);
                                       }
                       printf("\n\n");
                     }

void listar(int l[]){
                     int i;
                     for(i=0;i<2;i++){
                                       printf("%i, ",l[i]);
                                     }
                     printf("\n\n");
                    }
