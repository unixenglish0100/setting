// programa sobre funciones de tipo void sobre factorial
# include <stdio.h>
void factorial();
void primo();
int main(){

system("clear");
factorial();
primo();


printf("\n\nsaca en pantalla despues de ejecutar las dos funciones de tipo void\n\n");

return 0;
}

void factorial(){
                  int a,i,fac;
                  printf("\n\ndigite numero:   ");
                  scanf("%i",&a);
                  fac=1;
                  for(i=1;i<=a;i++){
                                     fac*=i;
                                   }
                  printf("\n\nel factorial de %i es %i\n\n",a,fac);
                }

void primo(){
              int n,j,k,aux;
              printf("\n\ndigite numero pa listar si es primo:   ");
              scanf("%i",&n);
              k=0;
              for(j=2;j<n && k!=1;j++){
                                         aux=n%j;
                                         if(aux==0){
                                                     k=1;
                                                   }
                              }
              if(k==0){
                        printf("\n\nel numero %i es primo\n\n",n);
                      }
              else{
                    printf("\n\nel numero %i no es primo\n\n",n);
                  }
            }
  

