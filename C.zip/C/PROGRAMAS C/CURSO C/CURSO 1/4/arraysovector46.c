//programa sobre vectores o arrays
#include<stdio.h>
int main(){
system("clear");

int v[]={3,5,23,1,2000};
int i;
//printf("\n\nel arrays de la posicion 0 es %i\n\n",v[0]);

for(i=0;i<5;i++){
                  printf("%i, ",v[i]);
                }
printf("\n\n");

return 0;
}
