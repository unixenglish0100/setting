// programa sobre punteros hace cambiar la variable a a b y b a a
# include <stdio.h>
void cambio(int *a,int *b);
int main(){

int x,y;
x=4;
y=12;

cambio(&x,&y);

printf("\n\nx = %i   y = %i\n\n",x,y);

return 0;
}

void cambio(int *a,int *b){
                            int aux;
                            aux=*a;
                            *a=*b;
                            *b=aux;
                          }

