//programa sobre arreglos o vectores en una funcion que ordena los numeros de menor a mayor
#include<stdio.h>
void ordenar(int a[10]);
void listar(int l[10]);
int main(){
system("clear");
int v[10]={7,5,4,1};

ordenar(v);
listar(v);

return 0;
}

void ordenar(int a[10]){
                         int i,j,aux;
                         for(i=0;i<4;i++){
                                           for(j=i;j<4;j++){
                                                              if(a[i]>a[j]){
                                                                              aux=a[i];
                                                                              a[i]=a[j];
                                                                              a[j]=aux;
                                                                           }
                                                           }
                                         }
                         printf("\n\n");
                       }

void listar(int l[10]){
                        int i;
                        for(i=0;i<4;i++){
                                          printf("%i, ",l[i]);
                                        }
                        printf("\n\n");
                      }
