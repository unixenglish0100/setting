// programa sobre punteros
# include <stdio.h>
int main(){

int x,*y;
system("clear");

x=4;
y=&x;

printf("\n\nel valor de *y es %i\n\n",*y);

return 0;

}
