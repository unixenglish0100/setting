<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="en-US">

<head profile="http://gmpg.org/xfn/11">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />

<title>  Page not found | Proyectos Beta</title>
<link rel="stylesheet" href="http://proyectosbeta.net/wp-content/themes/Vivex/css/screen.css" type="text/css" media="screen, projection" />
<link rel="stylesheet" href="http://proyectosbeta.net/wp-content/themes/Vivex/css/print.css" type="text/css" media="print" />
<!--[if IE]><link rel="stylesheet" href="http://proyectosbeta.net/wp-content/themes/Vivex/css/ie.css" type="text/css" media="screen, projection"><![endif]-->
<link rel="stylesheet" href="http://proyectosbeta.net/wp-content/themes/Vivex/style.css" type="text/css" media="screen" />
<!--[if IE 6]>
	<script src="http://proyectosbeta.net/wp-content/themes/Vivex/js/pngfix.js"></script>
<![endif]--> 
<link rel="shortcut icon" href="http://1.bp.blogspot.com/_Ain1HbvlMRk/S-757KK1mGI/AAAAAAAAAss/39qe61CjSdE/s1600/Proyectos+beta4oficial_16px_12px.png" type="image/x-icon" />
<link rel="alternate" type="application/rss+xml" title="Proyectos Beta RSS Feed" href="http://proyectosbeta.net/feed/" />
<link rel="alternate" type="application/atom+xml" title="Proyectos Beta Atom Feed" href="http://proyectosbeta.net/feed/atom/" />
<link rel="pingback" href="http://proyectosbeta.net/xmlrpc.php" />

<script src="http://proyectosbeta.net/wp-content/themes/Vivex/menu/mootools-1.2.1-core-yc.js" type="text/javascript"></script>
<link rel="stylesheet" href="http://proyectosbeta.net/wp-content/themes/Vivex/menu/MenuMatic.css" type="text/css" media="screen" charset="utf-8" />
<!--[if lt IE 7]>
	<link rel="stylesheet" href="http://proyectosbeta.net/wp-content/themes/Vivex/menu/MenuMatic-ie6.css" type="text/css" media="screen" charset="utf-8" />
<![endif]-->
<!-- Load the MenuMatic Class -->
<script src="http://proyectosbeta.net/wp-content/themes/Vivex/menu/MenuMatic_0.68.3.js" type="text/javascript" charset="utf-8"></script>


<link rel="EditURI" type="application/rsd+xml" title="RSD" href="http://proyectosbeta.net/xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="http://proyectosbeta.net/wp-includes/wlwmanifest.xml" /> 
<meta name="generator" content="WordPress 4.0" />
	<style type="text/css">.recentcomments a{display:inline !important;padding:0 !important;margin:0 !important;}</style>
<style type="text/css" id="custom-background-css">
body.custom-background { background-color: #fefdea; }
</style>

<!-- Inicio Google Analylics -->
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-12679048-5', 'proyectosbeta.net');
  ga('send', 'pageview');
</script>
<!-- Fin Google Analylics -->

<!-- Facebook Open Graph Tags -->
<meta property="fb:app_id" content="378677065544597"/>
<!-- End Facebook Open Graph Tags -->
</head>
<body>
<!--  inicio comentarios - Facebook //-->
<!-- Facebook JavaScript SDK -->
<div id="fb-root"></div>
<script>
    window.fbAsyncInit = function() {
        FB.init({appId: '378677065544597', status: true, cookie: true,
       xfbml: true});
    };
 
    (function() {
        var e = document.createElement('script'); e.async = true;
        e.src = document.location.protocol +
'       //connect.facebook.net/en_US/all.js';
        document.getElementById('fb-root').appendChild(e);
    }());
</script>
<!-- End Facebook JavaScript SDK -->
<!--  Fin comentarios - Facebook //-->
<script type="text/javascript">
	window.addEvent('domready', function() {			
			var myMenu = new MenuMatic();
	});	
</script>

	<div id="wrapper">
		<div id="container" class="container">  
			<div class="span-24">
				<div class="span-21">
					<div id="pagemenucontainer">
											</div>
				</div>
                
                <div class="span-3 feedtwitter last">
					<a href="http://proyectosbeta.net/feed/"><img src="http://proyectosbeta.net/wp-content/themes/Vivex/images/rss.png"  style="margin:0 4px 0 0;"  /></a>		
									</div>
			</div>
				<div id="header" class="span-24">
					<div class="span-12">
													<a href="http://proyectosbeta.net"><img src="http://proyectosbeta.net/wp-content/uploads/2012/05/Proyectos-beta4oficial.png" alt="Proyectos Beta" title="Proyectos Beta" class="logoimg" /></a>
													
					</div>
					
					<div class="span-12 last">
                        <div style="padding: 26px 0 0 0; text-align:right;">
						                          </div>
					</div>
				</div>
			
			<div class="span-24">
				<div id="navcontainer">
					<ul id="nav" class="menu"><li id="menu-item-40" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-home menu-item-40"><a title="Inicio" href="http://proyectosbeta.net/">Inicio</a></li>
<li id="menu-item-13735" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-13735"><a title="Eventos" target="_blank" href="http://eventos.proyectosbeta.net/">Eventos</a></li>
<li id="menu-item-45" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-45"><a title="Labs" href="http://proyectosbeta.net/labs/">Labs</a></li>
<li id="menu-item-56" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-56"><a title="Códigos Fuentes" href="http://proyectosbeta.net/codigofuente/">Códigos Fuentes</a></li>
<li id="menu-item-42" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-42"><a title="Acerca de" href="http://proyectosbeta.net/about/">Acerca de</a></li>
</ul>				</div>
			</div><div class="span-24" id="contentwrap">
	<div class="span-16">
		<div id="content">	
			<h2 class='pagetitle'>Error 404 - Page Not Found</h2>
		</div>
	</div>

<div class="span-8 last">
	
	<div class="sidebar">
    
    <div id="topsearch">
		 
<div id="search">
    <form method="get" id="searchform" action="http://proyectosbeta.net/"> 
        <input type="text" value="Search" 
            name="s" id="s"  onblur="if (this.value == '')  {this.value = 'Search';}"  
            onfocus="if (this.value == 'Search') {this.value = '';}" />
        <input type="image" src="http://proyectosbeta.net/wp-content/themes/Vivex/images/search.gif" style="border:0; vertical-align: top;" /> 
    </form>
</div> 
	</div>
	
            
    
    
            
        
    	
        
		<ul>
			<li id="text-8" class="widget widget_text">			<div class="textwidget"><div id='welcome'>
    <table border='1' summary='Suscripciones Gratuitas'>
        <tr>
	    <td>
	        <!-- Inicializar contador de RSS -->
		    <center>
		        <a href="http://feeds.feedburner.com/proyectosbetanet"><img src="http://feeds.feedburner.com/~fc/proyectosbetanet?bg=F7BB2C&amp;fg=000000&amp;anim=1" height="26" width="88" style="border:0" alt="" /></a>
		    </center>	
		<!-- Finalizar contador de RSS -->
	    </td>
	    <td>
	        <center>
	            <script language='JavaScript' src='http://twittercounter.com/embed/proyectosbeta/ffffff/111111' type='text/javascript'>
	            </script>
	        </center>
	    </td>
         </tr>
     </table>
</div></div>
		</li><li id="text-9" class="widget widget_text">			<div class="textwidget"><form style="border:0px solid #ccc;padding:3px;text-align:center;" action="http://feedburner.google.com/fb/a/mailverify" method="post" target="popupwindow" onsubmit="window.open('http://feedburner.google.com/fb/a/mailverify?uri=proyectosbetanet', 'popupwindow', 'scrollbars=yes,width=550,height=520');return true"><p>Recibir Artículos por Correo:</p><p><input type="text" style="width:200px" name="email" value="Escribe tu correo electrónico"/></p><input type="hidden" value="proyectosbetanet" name="uri"/><input type="hidden" name="loc" value="es_ES"/><input type="submit" value="Suscribir" /></form></div>
		</li><li id="text-7" class="widget widget_text">			<div class="textwidget"><p><script type="text/javascript"><!--
google_ad_client = "ca-pub-1115401915888158";
/* ProyectosBeta.net1 */
google_ad_slot = "9448239670";
google_ad_width = 300;
google_ad_height = 250;
//-->
</script><br />
<script type="text/javascript"
src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script></p>
</div>
		</li><li id="text-5" class="widget widget_text"><h2 class="widgettitle">Síganos los Betas</h2>			<div class="textwidget"><p><iframe src="//www.facebook.com/plugins/likebox.php?href=http%3A%2F%2Fwww.facebook.com%2Fpages%2FProyectos-Beta%2F113277785412256&amp;width=290&amp;height=290&amp;colorscheme=light&amp;show_faces=true&amp;border_color&amp;stream=false&amp;header=true&amp;appId=134023446657909" scrolling="no" frameborder="0" style="border:none; overflow:hidden; width:290px; height:290px;" allowTransparency="true"></iframe></p>
</div>
		</li><li id="recent-comments-3" class="widget widget_recent_comments"><h2 class="widgettitle">Beta comentarios</h2><ul id="recentcomments"><li class="recentcomments"><span class="comment-author-link">Bernardo</span> on <a href="http://proyectosbeta.net/2013/04/un-ejemplo-usando-un-apdater-personalizado-listview-en-android/#comment-81037">Un ejemplo usando un Adapter personalizado, ListView en Android</a></li><li class="recentcomments"><span class="comment-author-link">Manuel</span> on <a href="http://proyectosbeta.net/2014/09/existen-beneficios-economicos-con-la-participacion-de-eventos-compartir-el-codigo-fuente-etc/#comment-81011">¿Existen beneficios económicos con la participación de eventos, compartir el código fuente, etc?</a></li><li class="recentcomments"><span class="comment-author-link"><a href='http://proyectosbeta.net' rel='external nofollow' class='url'>José González von Schmeling</a></span> on <a href="http://proyectosbeta.net/2014/09/existen-beneficios-economicos-con-la-participacion-de-eventos-compartir-el-codigo-fuente-etc/#comment-81009">¿Existen beneficios económicos con la participación de eventos, compartir el código fuente, etc?</a></li><li class="recentcomments"><span class="comment-author-link">Manuel</span> on <a href="http://proyectosbeta.net/2014/09/existen-beneficios-economicos-con-la-participacion-de-eventos-compartir-el-codigo-fuente-etc/#comment-80928">¿Existen beneficios económicos con la participación de eventos, compartir el código fuente, etc?</a></li><li class="recentcomments"><span class="comment-author-link"><a href='http://proyectosbeta.net' rel='external nofollow' class='url'>José González von Schmeling</a></span> on <a href="http://proyectosbeta.net/2014/04/instalar-skype-4-2-en-ubuntu-14-04-lts-de-64-bits/#comment-80918">Instalar Skype 4.2 en Ubuntu 14.04 LTS de 64 bits</a></li><li class="recentcomments"><span class="comment-author-link"><a href='http://proyectosbeta.net' rel='external nofollow' class='url'>José González von Schmeling</a></span> on <a href="http://proyectosbeta.net/2014/04/instalar-vlc-2-1-5-en-ubuntu-14-04-lts/#comment-80917">Instalar vlc 2.1.5 en Ubuntu 14.04 LTS</a></li></ul></li><li id="linkcat-2" class="widget widget_links"><h2 class="widgettitle">Blogroll</h2>
	<ul class='xoxo blogroll'>
<li><a href="http://proyectosbeta.blogspot.com/" title="Mi blog en Blogger" target="_blank">Proyectos Beta (Blogger)</a></li>

	</ul>
</li>
<li id="archives-3" class="widget widget_archive"><h2 class="widgettitle">Archives</h2>		<ul>
	<li><a href='http://proyectosbeta.net/2014/09/'>September 2014</a></li>
	<li><a href='http://proyectosbeta.net/2014/08/'>August 2014</a></li>
	<li><a href='http://proyectosbeta.net/2014/07/'>July 2014</a></li>
	<li><a href='http://proyectosbeta.net/2014/06/'>June 2014</a></li>
	<li><a href='http://proyectosbeta.net/2014/05/'>May 2014</a></li>
	<li><a href='http://proyectosbeta.net/2014/04/'>April 2014</a></li>
	<li><a href='http://proyectosbeta.net/2014/03/'>March 2014</a></li>
	<li><a href='http://proyectosbeta.net/2014/02/'>February 2014</a></li>
	<li><a href='http://proyectosbeta.net/2014/01/'>January 2014</a></li>
	<li><a href='http://proyectosbeta.net/2013/12/'>December 2013</a></li>
	<li><a href='http://proyectosbeta.net/2013/11/'>November 2013</a></li>
	<li><a href='http://proyectosbeta.net/2013/10/'>October 2013</a></li>
	<li><a href='http://proyectosbeta.net/2013/09/'>September 2013</a></li>
	<li><a href='http://proyectosbeta.net/2013/08/'>August 2013</a></li>
	<li><a href='http://proyectosbeta.net/2013/07/'>July 2013</a></li>
	<li><a href='http://proyectosbeta.net/2013/06/'>June 2013</a></li>
	<li><a href='http://proyectosbeta.net/2013/05/'>May 2013</a></li>
	<li><a href='http://proyectosbeta.net/2013/04/'>April 2013</a></li>
	<li><a href='http://proyectosbeta.net/2013/03/'>March 2013</a></li>
	<li><a href='http://proyectosbeta.net/2013/02/'>February 2013</a></li>
	<li><a href='http://proyectosbeta.net/2013/01/'>January 2013</a></li>
	<li><a href='http://proyectosbeta.net/2012/12/'>December 2012</a></li>
	<li><a href='http://proyectosbeta.net/2012/11/'>November 2012</a></li>
	<li><a href='http://proyectosbeta.net/2012/10/'>October 2012</a></li>
	<li><a href='http://proyectosbeta.net/2012/09/'>September 2012</a></li>
	<li><a href='http://proyectosbeta.net/2012/08/'>August 2012</a></li>
	<li><a href='http://proyectosbeta.net/2012/07/'>July 2012</a></li>
	<li><a href='http://proyectosbeta.net/2012/06/'>June 2012</a></li>
	<li><a href='http://proyectosbeta.net/2012/05/'>May 2012</a></li>
		</ul>
</li><li id="categories-3" class="widget widget_categories"><h2 class="widgettitle">Categories</h2>		<ul>
	<li class="cat-item cat-item-8"><a href="http://proyectosbeta.net/category/base-de-datos/" >Base de datos</a> (60)
</li>
	<li class="cat-item cat-item-176"><a href="http://proyectosbeta.net/category/concurso/" >Concurso</a> (2)
</li>
	<li class="cat-item cat-item-15"><a href="http://proyectosbeta.net/category/cursos/" >Cursos</a> (13)
</li>
	<li class="cat-item cat-item-244"><a href="http://proyectosbeta.net/category/datos-abiertos/" >Datos Abiertos</a> (1)
</li>
	<li class="cat-item cat-item-58"><a href="http://proyectosbeta.net/category/diseno/" >Diseño</a> (5)
</li>
	<li class="cat-item cat-item-200"><a href="http://proyectosbeta.net/category/educacion/" >Educación</a> (4)
</li>
	<li class="cat-item cat-item-20"><a href="http://proyectosbeta.net/category/eventos/" >Eventos</a> (38)
</li>
	<li class="cat-item cat-item-13"><a href="http://proyectosbeta.net/category/gis/" >GIS</a> (141)
</li>
	<li class="cat-item cat-item-29"><a href="http://proyectosbeta.net/category/hardware/" >Hardware</a> (9)
</li>
	<li class="cat-item cat-item-40"><a href="http://proyectosbeta.net/category/humor/" >Humor</a> (104)
</li>
	<li class="cat-item cat-item-31"><a href="http://proyectosbeta.net/category/imagenes-2/" >Imágenes</a> (154)
</li>
	<li class="cat-item cat-item-34"><a href="http://proyectosbeta.net/category/juegos/" >Juegos</a> (22)
</li>
	<li class="cat-item cat-item-164"><a href="http://proyectosbeta.net/category/medio-ambiente/" >Medio Ambiente</a> (2)
</li>
	<li class="cat-item cat-item-72"><a href="http://proyectosbeta.net/category/movil/" >Móvil</a> (51)
</li>
	<li class="cat-item cat-item-75"><a href="http://proyectosbeta.net/category/multimedia/" >Multimedia</a> (43)
</li>
	<li class="cat-item cat-item-73"><a href="http://proyectosbeta.net/category/ofimatica/" >Ofimática</a> (3)
</li>
	<li class="cat-item cat-item-19"><a href="http://proyectosbeta.net/category/programacion/" >Programación</a> (166)
</li>
	<li class="cat-item cat-item-219"><a href="http://proyectosbeta.net/category/proyectos/" >Proyectos</a> (1)
</li>
	<li class="cat-item cat-item-37"><a href="http://proyectosbeta.net/category/recursos/" >Recursos</a> (61)
</li>
	<li class="cat-item cat-item-130"><a href="http://proyectosbeta.net/category/redes/" >Redes</a> (4)
</li>
	<li class="cat-item cat-item-69"><a href="http://proyectosbeta.net/category/redes-sociales/" >Redes Sociales</a> (8)
</li>
	<li class="cat-item cat-item-7"><a href="http://proyectosbeta.net/category/revistas/" >Revistas</a> (41)
</li>
	<li class="cat-item cat-item-24"><a href="http://proyectosbeta.net/category/seguridad/" >Seguridad</a> (19)
</li>
	<li class="cat-item cat-item-18"><a href="http://proyectosbeta.net/category/sistemas-operativos/" >Sistemas Operativos</a> (621)
</li>
	<li class="cat-item cat-item-32"><a href="http://proyectosbeta.net/category/tablet/" >Tablet</a> (22)
</li>
	<li class="cat-item cat-item-12"><a href="http://proyectosbeta.net/category/varios/" >Varios</a> (53)
</li>
	<li class="cat-item cat-item-26"><a href="http://proyectosbeta.net/category/videos/" >Vídeos</a> (12)
</li>
	<li class="cat-item cat-item-21"><a href="http://proyectosbeta.net/category/virtualizacion/" >Virtualización</a> (25)
</li>
	<li class="cat-item cat-item-82"><a href="http://proyectosbeta.net/category/web/" >Web</a> (4)
</li>
		</ul>
</li>		</ul>
        
			</div>
</div>


<div class="partner_lnk"><a href="http://www.mr-movie.com/">download divx movies</a></div>	</div>
<div class="span-24">	
	<div id="footer">Copyright &copy; <a href="http://proyectosbeta.net"><strong>Proyectos Beta</strong></a>  - </div>
    
            
    <div id="credits">Powered by <a href="http://wordpress.org/"><strong>WordPress</strong></a> | Free <a href="http://fthemes.com/">WordPress Templates</a> by Free <a href="http://fthemes.com/">WordPress Themes</a> | Thanks to <a href="http://fthemes.com/todays-news-free-wordpress-theme/">WordPress News Themes</a> and <a href="http://wordpress3themes.com/">WordPress 3 Themes</a></div>
    
    </div>	
</div>	
</div>

</body>
</html>